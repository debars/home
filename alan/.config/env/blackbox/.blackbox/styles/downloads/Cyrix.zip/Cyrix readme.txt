Cyrix, the style, was based on the wallpaper "Cyrix" by danillooc (http://danillooc.wincustomize.com, http://danillooc.deviantart.com) with the artist's permission. This is an excerpt of the permission:

Pete,
You have my permission to use the Cyrix Wallpaper,
in your BlackBox theme and upload it over the GUI
community sites 

~danilloOc

Thanx,danillooc!