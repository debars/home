-------------------------------------------------------------

\\ BroamTimer 0.0.1

-------------------------------------------------------------

[ Purpose ]

    --  Reads a list of bro@ms from a file.
    --  Dispatches the bro@ms on a timer.
    --  (Mostly intended for BBInterface.)

-------------------------------------------------------------

[ Installation ]

    Add a path to BroamTimer.dll in plugins.rc.

-------------------------------------------------------------

[ RC Settings ]

    in BroamTimer.rc:

        Interval:   2000    (sets timer-inverval in milliseconds)

    in Broams.rc:

        --  bro@ms should be listed here, one-per-line

        --  use "#" or "!" to comment out a line

-------------------------------------------------------------

[ Bro@ms ]

    @BroamTimer.Play

        --  begin sending bro@ms from beginning of list

    @BroamTimer.Stop

        --  stop sending bro@ms

        --  "reset pointer" to beginning of list

    @BroamTimer.Pause

        --  stop sending bro@ms

        --  doesn't reset pointer

    @BroamTimer.Resume

        --  begin sending bro@ms from last location

        --  doesn't reset pointer

    @BroamTimer.Toggle

        -- if currently sending bro@ms, "resume"...otherwise, "pause"

    @BroamTimer.Read

        -- read and apply settings from rc files

        -- doesn't affect play/stopped status

-------------------------------------------------------------

[ License ]

    BroamTimer � 2004 Slade Taylor

    For details, see source files.

-------------------------------------------------------------

[ Contact ]

    bladestaylor@yahoo.com

    http://bb4win.sourceforge.net/bladestaylor

-------------------------------------------------------------

[ Changes ]

    (0.0.1 - May 17, 2004)

        -- initial release

-------------------------------------------------------------
