/*---------------------------------------------------------------------------------
 BroamRelay (� 2004 Slade Taylor [bladestaylor@yahoo.com])
 ----------------------------------------------------------------------------------
 BroamRelay is a plugin for Blackbox for Windows.  For more information,
 please visit [http://bb4win.org] or [http://sourceforge.net/projects/bb4win].
 ----------------------------------------------------------------------------------
 BroamRelay is free software, released under the GNU General Public License,
 version 2, as published by the Free Software Foundation.  It is distributed
 WITHOUT ANY WARRANTY--without even the implied warranty of MERCHANTABILITY
 or FITNESS FOR A PARTICULAR PURPOSE.  Please see the GNU General Public
 License for more details:  [http://www.fsf.org/licenses/gpl.html].
 --------------------------------------------------------------------------------*/

#define VC_EXTRALEAN
#define WIN32_LEAN_AND_MEAN

#include "../Blackbox/BBApi.h"

#define BR_CLASSNAME "BroamRelay"
#define BR_WINDOWNAME BP_CLASSNAME

#define MAX_LINE_LENGTH			4096

//-------------------------------------------------------------------------------------

static FILE *br_file;
static HWND hCoreWnd, hBRWnd;
static char *br_path, br_buffer[MAX_LINE_LENGTH];
static int bb_messages[] = {BB_BROADCAST, 0};

//-------------------------------------------------------------------------------------

extern "C"
{
	__declspec(dllexport) int beginPlugin(HINSTANCE);
	__declspec(dllexport) void endPlugin(HINSTANCE);
	__declspec(dllexport) LPCSTR pluginInfo(int field) { return " "; };
}

//-------------------------------------------------------------------------------------

LRESULT CALLBACK brProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp)
{
	if ((msg == BB_BROADCAST) && 
		!strncmp(br_path = (char*)lp, "@BroamRelay ", 12) && 
		(br_file = FileOpen(br_path + 12)))
	{
		while (ReadNextCommand(br_file, br_buffer, 1024))
			SendMessage(hCoreWnd, BB_BROADCAST, NULL, (LPARAM)br_buffer);
		return FileClose(br_file);
	}
	return DefWindowProc(hwnd, msg, wp, lp);
}

//-------------------------------------------------------------------------------------

int beginPlugin(HINSTANCE hPluginInstance)
{
	WNDCLASS wc;
	hCoreWnd = GetBBWnd();

	ZeroMemory((void*)&wc, sizeof(wc));
	wc.lpfnWndProc = brProc;
	wc.hInstance = hPluginInstance;
	wc.lpszClassName = BR_CLASSNAME;
	RegisterClass(&wc);

	hBRWnd = CreateWindowEx(
		WS_EX_TOOLWINDOW,
		BR_CLASSNAME,
		NULL,
		WS_POPUP,
		0, 0, 0, 0,
		HWND_MESSAGE,
		NULL,
		hPluginInstance,
		NULL
	);

	SendMessage(hCoreWnd, BB_REGISTERMESSAGE, (WPARAM)hBRWnd, (LPARAM)bb_messages);
	return 0;
}

//-------------------------------------------------------------------------------------

void endPlugin(HINSTANCE hPluginInstance)
{
	SendMessage(hCoreWnd, BB_UNREGISTERMESSAGE, (WPARAM)hBRWnd, (LPARAM)bb_messages);
	DestroyWindow(hBRWnd);
	UnregisterClass(BR_CLASSNAME, hPluginInstance);
	return;
}

//-------------------------------------------------------------------------------------

bool APIENTRY DllMain(HANDLE hDLL, DWORD dwReason, LPVOID lpReserved) { return true; };

//-------------------------------------------------------------------------------------
