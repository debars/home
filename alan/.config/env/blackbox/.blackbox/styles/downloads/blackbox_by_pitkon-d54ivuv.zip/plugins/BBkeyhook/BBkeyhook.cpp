/*
 ============================================================================
 Kaloth's First BB4win plugin! - BBkeyhook
 ============================================================================
 
 This plugin lets you assign any key on your keyboard to mute, volume up or
 volume down. I made it so that my multi media keyboard could work properly
 under BB4win.
 
 ============================================================================
*/

#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x0500
#endif

#ifdef __GNUC__
#define _WIN32_IE 0x0500
#define GetBlackboxPath _GetBlackboxPath
#define DLL_EXPORT //__declspec(dllexport)
#define LWA_ALPHA 2
#endif

#ifdef __BORLANDC__
#define DLL_EXPORT
#endif

#include "../../includes/BBApi.h"
#include <stdlib.h>
#include <string.h>
#include <windows.h>
#include <mmsystem.h>

void ReadRCSettings();

extern "C"
{
	DLL_EXPORT int beginPlugin(HINSTANCE hMainInstance);
	DLL_EXPORT void endPlugin(HINSTANCE hMainInstance);
	DLL_EXPORT LPCSTR pluginInfo(int field);
}

LPSTR szAppName         = "BBkeyhook";          // The name of our window class, etc.
LPSTR szVersion         = "BBkeyhook v0.5b";   // Used in MessageBox titlebars
LPSTR szInfoVersion     = "v0.5b";
LPSTR szInfoAuthor      = "Kaloth";
LPSTR szInfoRelDate     = "14-10-2005";
LPSTR szInfoLink        = "http://www.geocities.com/madant8";
LPSTR szInfoEmail       = "mulletwarriorextreem@hotmail.com";
LPSTR updateURL		= "www.geocities.com/madant8/meta.txt";
#define PLUGIN_UPDATE_URL 124

//===========================================================================
HINSTANCE hInstance;
HWND hwndPlugin, hwndBlackbox;
OSVERSIONINFO  osvinfo;

char rcpath[MAX_PATH];

bool usingWin2kXP;

HHOOK HKbHook;
HMIXER hMixer;

DWORD dwThreadId;
HANDLE hThread;

int keys[25]; // 25 stored virtual key codes.
int codes[25]; // 25 stored key scan codes.
char commands[25][MAX_LINE_LENGTH]; // 25 stored commands.
char arguments[25][MAX_LINE_LENGTH]; // 25 stored arguments.

bool config = true;
int volume_step = 655;
int current_command = -1;

//===========================================================================

void muteToggle();
void volumeUp();
void volumeDown();

DWORD WINAPI CommandProc(LPVOID lpParam){
	int n = current_command;
	
	if(n == -1){
		hThread = NULL;
		return 0;
	}
	
	
	if(commands[n] != '\0'){
		if(strstr(commands[n], "#MIXER.") != NULL){
			if(strstr(commands[n], "MUTE#") != NULL){
				muteToggle();
			}else if(strstr(commands[n], "VOLUME.UP#") != NULL){
				volumeUp();
			}else if(strstr(commands[n], "VOLUME.DOWN#") != NULL){
				volumeDown();
			}else{
				MessageBox(NULL, "The only valid mixer commands are...\n\n#MIXER.MUTE#\n#MIXER.VOLUME.UP#\n#MIXER.VOLUME.DOWN#", "BBkeyhook - Invalid Mixer Command", MB_OK | MB_ICONERROR);
			}
		}else if(strstr(commands[n], "@") != NULL){
			SendMessage(hwndBlackbox, BB_BROADCAST, 0, (LPARAM)commands[n]);
		}else{
			char directory[MAX_LINE_LENGTH];
			char command[MAX_LINE_LENGTH];
			command[0] = '\0';
			strcpy(directory, commands[n]);
			
			if(strcmp(directory, "") != 0){
				int nLen;
				
				nLen = strlen(directory) - 1;
				while (nLen > 0 && directory[nLen] != '\\') nLen--;
				directory[nLen] = '\0';
				
				if(nLen == 0){
					strcpy(command, commands[n]);
				}else{
					int i;
					for(i = nLen + 1; i <= strlen(commands[n]); i++){
						command[i - nLen - 1] = commands[n][i];
					}
				}
			}
			
			char buffer[MAX_LINE_LENGTH];
			sprintf(buffer, "BBKeyhook -> %s", command);
			SendMessage(hwndBlackbox, BB_SETTOOLBARLABEL, 0, (LPARAM)buffer);
			
			BBExecute(NULL, "", command, arguments[n], directory, SW_SHOWNORMAL, true);
		}
	}
	
	hThread = NULL;
	return 0;
}

MMRESULT openMixer(){
	// Get a handle on that mixer!
	return mixerOpen(&hMixer, MIXER_OBJECTF_MIXER, 0, 0, 0);
}

MMRESULT closeMixer(){
	// Close that mixer!
	return mixerClose(hMixer);
}

int getMasterVolume(){
	MMRESULT result;
	// Grab the speaker line!
	MIXERLINE ml = {0};
	ml.cbStruct = sizeof(MIXERLINE);
	ml.dwComponentType = MIXERLINE_COMPONENTTYPE_DST_SPEAKERS;
	result = mixerGetLineInfo((HMIXEROBJ) hMixer, &ml, MIXER_GETLINEINFOF_COMPONENTTYPE);
	if(result != MMSYSERR_NOERROR){return -1;}
	// Get the volume control of the speaker line...
	MIXERLINECONTROLS mlc = {0};
	MIXERCONTROL mc = {0};
	mlc.cbStruct = sizeof(MIXERLINECONTROLS);
	mlc.dwLineID = ml.dwLineID;
	mlc.dwControlType = MIXERCONTROL_CONTROLTYPE_VOLUME;
	mlc.cControls = 1;
	mlc.pamxctrl = &mc;
	mlc.cbmxctrl = sizeof(MIXERCONTROL);
	result = mixerGetLineControls((HMIXEROBJ) hMixer, &mlc, MIXER_GETLINECONTROLSF_ONEBYTYPE);
	if(result != MMSYSERR_NOERROR){return -1;}
	// Now we got everything, get the volume!
	MIXERCONTROLDETAILS mcd = {0};
	MIXERCONTROLDETAILS_UNSIGNED mcdu = {0};
	//mcdu.dwValue = 0; // Leave this alone so it can get a value!
	mcd.cbStruct = sizeof(MIXERCONTROLDETAILS);
	mcd.hwndOwner = 0;
	mcd.dwControlID = mc.dwControlID;
	mcd.paDetails = &mcdu;
	mcd.cbDetails = sizeof(MIXERCONTROLDETAILS_UNSIGNED);
	mcd.cChannels = 1;
	result = mixerGetControlDetails((HMIXEROBJ) hMixer, &mcd, MIXER_SETCONTROLDETAILSF_VALUE);
	if(result != MMSYSERR_NOERROR){
		return -1;
	}
	return mcdu.dwValue;
}

//===========================================================================

int getMasterMute(){
	MMRESULT result;
	// Grab the speaker line!
	MIXERLINE ml = {0};
	ml.cbStruct = sizeof(MIXERLINE);
	ml.dwComponentType = MIXERLINE_COMPONENTTYPE_DST_SPEAKERS;
	result = mixerGetLineInfo((HMIXEROBJ) hMixer, &ml, MIXER_GETLINEINFOF_COMPONENTTYPE);
	if(result != MMSYSERR_NOERROR){return -1;}
	// Get the volume control of the speaker line...
	MIXERLINECONTROLS mlc = {0};
	MIXERCONTROL mc = {0};
	mlc.cbStruct = sizeof(MIXERLINECONTROLS);
	mlc.dwLineID = ml.dwLineID;
	mlc.dwControlType = MIXERCONTROL_CONTROLTYPE_MUTE;
	mlc.cControls = 1;
	mlc.pamxctrl = &mc;
	mlc.cbmxctrl = sizeof(MIXERCONTROL);
	result = mixerGetLineControls((HMIXEROBJ) hMixer, &mlc, MIXER_GETLINECONTROLSF_ONEBYTYPE);
	if(result != MMSYSERR_NOERROR){return -1;}
	// Now we got everything, get the volume!
	MIXERCONTROLDETAILS mcd = {0};
	MIXERCONTROLDETAILS_BOOLEAN mcdu = {0};
	//mcdu.fValue = 0; // Leave this alone so it can get a value!
	mcd.cbStruct = sizeof(MIXERCONTROLDETAILS);
	mcd.hwndOwner = 0;
	mcd.dwControlID = mc.dwControlID;
	mcd.paDetails = &mcdu;
	mcd.cbDetails = sizeof(MIXERCONTROLDETAILS_UNSIGNED);
	mcd.cChannels = 1;
	result = mixerGetControlDetails((HMIXEROBJ) hMixer, &mcd, MIXER_SETCONTROLDETAILSF_VALUE);
	if(result != MMSYSERR_NOERROR){
		return -1;
	}
	return mcdu.fValue;
}

//===========================================================================

MMRESULT setMasterVolume(int vol){
	MMRESULT result;
	// Grab the speaker line!
	MIXERLINE ml = {0};
	ml.cbStruct = sizeof(MIXERLINE);
	ml.dwComponentType = MIXERLINE_COMPONENTTYPE_DST_SPEAKERS;
	result = mixerGetLineInfo((HMIXEROBJ) hMixer, &ml, MIXER_GETLINEINFOF_COMPONENTTYPE);
	if(result != MMSYSERR_NOERROR){return result;}
	// Get the volume control of the speaker line...
	MIXERLINECONTROLS mlc = {0};
	MIXERCONTROL mc = {0};
	mlc.cbStruct = sizeof(MIXERLINECONTROLS);
	mlc.dwLineID = ml.dwLineID;
	mlc.dwControlType = MIXERCONTROL_CONTROLTYPE_VOLUME;
	mlc.cControls = 1;
	mlc.pamxctrl = &mc;
	mlc.cbmxctrl = sizeof(MIXERCONTROL);
	result = mixerGetLineControls((HMIXEROBJ) hMixer, &mlc, MIXER_GETLINECONTROLSF_ONEBYTYPE);
	if(result != MMSYSERR_NOERROR){return result;}
	// Now we got everything, set the volume!
	MIXERCONTROLDETAILS mcd = {0};
	MIXERCONTROLDETAILS_UNSIGNED mcdu = {0};
	mcdu.dwValue = vol; // Set the volume to requested volume (vol).
	mcd.cbStruct = sizeof(MIXERCONTROLDETAILS);
	mcd.hwndOwner = 0;
	mcd.dwControlID = mc.dwControlID;
	mcd.paDetails = &mcdu;
	mcd.cbDetails = sizeof(MIXERCONTROLDETAILS_UNSIGNED);
	mcd.cChannels = 1;
	result = mixerSetControlDetails((HMIXEROBJ) hMixer, &mcd, MIXER_SETCONTROLDETAILSF_VALUE);
	return result;
}

//===========================================================================

MMRESULT setMasterMute(int val){
	MMRESULT result;
	// Grab the speaker line!
	MIXERLINE ml = {0};
	ml.cbStruct = sizeof(MIXERLINE);
	ml.dwComponentType = MIXERLINE_COMPONENTTYPE_DST_SPEAKERS;
	result = mixerGetLineInfo((HMIXEROBJ) hMixer, &ml, MIXER_GETLINEINFOF_COMPONENTTYPE);
	if(result != MMSYSERR_NOERROR){return result;}
	// Get the volume control of the speaker line...
	MIXERLINECONTROLS mlc = {0};
	MIXERCONTROL mc = {0};
	mlc.cbStruct = sizeof(MIXERLINECONTROLS);
	mlc.dwLineID = ml.dwLineID;
	mlc.dwControlType = MIXERCONTROL_CONTROLTYPE_MUTE;
	mlc.cControls = 1;
	mlc.pamxctrl = &mc;
	mlc.cbmxctrl = sizeof(MIXERCONTROL);
	result = mixerGetLineControls((HMIXEROBJ) hMixer, &mlc, MIXER_GETLINECONTROLSF_ONEBYTYPE);
	if(result != MMSYSERR_NOERROR){return result;}
	// Now we got everything, set the volume!
	MIXERCONTROLDETAILS mcd = {0};
	MIXERCONTROLDETAILS_BOOLEAN mcdu = {0};
	mcdu.fValue = val; // Set the volume to val.
	mcd.cbStruct = sizeof(MIXERCONTROLDETAILS);
	mcd.hwndOwner = 0;
	mcd.dwControlID = mc.dwControlID;
	mcd.paDetails = &mcdu;
	mcd.cbDetails = sizeof(MIXERCONTROLDETAILS_UNSIGNED);
	mcd.cChannels = 1;
	result = mixerSetControlDetails((HMIXEROBJ) hMixer, &mcd, MIXER_SETCONTROLDETAILSF_VALUE);
	return result;
}

void volumeUp(){
	MMRESULT result;
	int res = getMasterVolume();
	if(res != -1){
		res += volume_step;
		
		// Set the new volume...
		if(res > 65535){
			result = setMasterVolume(65535);
			res = 65535;
		}else{
			result = setMasterVolume(res);
		}
		
		// Tell the user what the new volume setting is...
		int p_vol = ((float)res/(float)65535)*100;
		char buffer [33];
		sprintf(buffer, "Volume Up (%d%)", p_vol);
		
		if(result == MMSYSERR_NOERROR){
			SendMessage(GetBBWnd(), BB_SETTOOLBARLABEL, 0, (LPARAM)buffer);
		}else{
			SendMessage(GetBBWnd(), BB_SETTOOLBARLABEL, 0, (LPARAM)"BBkeyhook -> Mixer Error!");
		}
	}else{
		SendMessage(GetBBWnd(), BB_SETTOOLBARLABEL, 0, (LPARAM)"BBkeyhook -> Mixer Error!");
	}
}

void volumeDown(){
	MMRESULT result;
	int res = getMasterVolume();
	if(res != -1){
		res -= volume_step;
		
		// Set the new volume...
		if(res < 0){
			result = setMasterVolume(0);
			res = 0;
		}else{
			result = setMasterVolume(res);
		}
		
		// Tell the user what the new volume setting is...
		int p_vol = ((float)res/(float)65535)*100;
		char buffer [33];
		sprintf(buffer, "Volume Up (%d%)", p_vol);
		
		if(result == MMSYSERR_NOERROR){
			SendMessage(GetBBWnd(), BB_SETTOOLBARLABEL, 0, (LPARAM)buffer);
		}else{
			SendMessage(GetBBWnd(), BB_SETTOOLBARLABEL, 0, (LPARAM)"BBkeyhook -> Mixer Error!");
		}
	}else{
		SendMessage(GetBBWnd(), BB_SETTOOLBARLABEL, 0, (LPARAM)"BBkeyhook -> Mixer Error!");
	}
}

void muteToggle(){
	MMRESULT result;
	int res = getMasterMute();
	if(res != -1){
		if(res == 0){
			result = setMasterMute(1);
			if(result == MMSYSERR_NOERROR){
				SendMessage(GetBBWnd(), BB_SETTOOLBARLABEL, 0, (LPARAM)"Mute");
			}else{
				SendMessage(GetBBWnd(), BB_SETTOOLBARLABEL, 0, (LPARAM)"BBkeyhook -> Mixer Error!");
			}
		}else if(res == 1){
			result = setMasterMute(0);
			if(result == MMSYSERR_NOERROR){
				SendMessage(GetBBWnd(), BB_SETTOOLBARLABEL, 0, (LPARAM)"Un-Mute");
			}else{
				SendMessage(GetBBWnd(), BB_SETTOOLBARLABEL, 0, (LPARAM)"BBkeyhook -> Mixer Error!");
			}
		}
	}else{
		SendMessage(GetBBWnd(), BB_SETTOOLBARLABEL, 0, (LPARAM)"BBkeyhook -> Mixer Error!");
	}
}

//===========================================================================

// The keyboard hook procedure.
LRESULT CALLBACK MyKBHook(int Code, WPARAM wParam, LPARAM lParam){
	if(Code >= 0 && wParam == WM_KEYDOWN){
		KBDLLHOOKSTRUCT *key = (KBDLLHOOKSTRUCT *)lParam;
		MMRESULT result;
		int n;
		for(n = 0; n < 25; n++){
			if(key->vkCode == keys[n]){
				if(codes[n] == -1 || codes[n] == key->scanCode){
					if(hThread == NULL){
						current_command = n;
						hThread = CreateThread(NULL, 0, CommandProc, 0, 0, &dwThreadId);
					}
				}
			}
		}
		
		if(config){
			char buffer [33];
			sprintf(buffer, "BBkh VK:%d SC:%d", key->vkCode, key->scanCode);
			SendMessage(GetBBWnd(), BB_SETTOOLBARLABEL, 0, (LPARAM)buffer);
		}
	}
	// Call the next hook in the chain.
	return CallNextHookEx(HKbHook, Code, wParam, lParam);
}

// Function that is used to install the keyboard hook.
void HookKb(){
	HKbHook = SetWindowsHookEx(WH_KEYBOARD_LL, (HOOKPROC)MyKBHook, GetModuleHandle(NULL), 0);
}

// Function that uninstalls all hooks.
void Unhook(){
	if (HKbHook != 0){UnhookWindowsHookEx(HKbHook);}
	HKbHook = 0;
}

//===========================================================================

int beginPlugin(HINSTANCE hPluginInstance){
	ZeroMemory(&osvinfo, sizeof(osvinfo));
	osvinfo.dwOSVersionInfoSize = sizeof (osvinfo);
	GetVersionEx(&osvinfo);
	usingWin2kXP =
		osvinfo.dwPlatformId == VER_PLATFORM_WIN32_NT
		&& osvinfo.dwMajorVersion > 4;

	hwndBlackbox = GetBBWnd();
	hInstance = hPluginInstance;

	// Get plugin and style settings...
	ReadRCSettings();
	
	// Hook the keyboard (only if win2000/XP!).
	if(usingWin2kXP){
		if(openMixer() == MMSYSERR_NOERROR){
			HookKb();
		}else{
			// Tell the user about the problem...
			MessageBox(NULL, "Could not obtain a handle on your mixer!", "BBkeyhook - ERROR!", MB_OK | MB_ICONERROR);
		}
	}else{
		// Tell the user about the problem...
		MessageBox(NULL, "BBkeyhook needs Win2000/XP!\n\nSorry :(", "BBkeyhook - ERROR!", MB_OK | MB_ICONERROR);
	}
	
	return 0;
}

//===========================================================================

void endPlugin(HINSTANCE hPluginInstance){
	// Unhook the keyboard (only if win2000/XP!).
	if(usingWin2kXP){Unhook();closeMixer();}
}

//===========================================================================

LPCSTR pluginInfo(int field){
	// pluginInfo is used by Blackbox for Windows to fetch information about
	// a particular plugin. At the moment this information is simply displayed
	// in an "About loaded plugins" MessageBox, but later on this will be
	// expanded into a more advanced plugin handling system. Stay tuned! :)
	switch (field)
	{
		case PLUGIN_NAME:
			return szAppName;       // Plugin name
		case PLUGIN_VERSION:
			return szInfoVersion;   // Plugin version
		case PLUGIN_AUTHOR:
			return szInfoAuthor;    // Author
		case PLUGIN_RELEASE:
			return szInfoRelDate;   // Release date, preferably in yyyy-mm-dd format
		case PLUGIN_LINK:
			return szInfoLink;      // Link to author's website
		case PLUGIN_EMAIL:
			return szInfoEmail;     // Author's email
		case PLUGIN_UPDATE_URL:
			return updateURL;	// Dev's online update meta file
		default:
			return szVersion;       // Fallback: Plugin name + version, e.g. "MyPlugin 1.0"
	}
}

//===========================================================================

void ReadRCSettings(){
	char defaultpath[MAX_PATH]; int nLen, i;
	// First we look for the config file in the same folder as the plugin...
	GetModuleFileName(hInstance, rcpath, sizeof(rcpath));
	for (i=0;;i++)
	{
		nLen = strlen(rcpath); while (nLen && rcpath[nLen-1] != '\\') nLen--;
		// ...check the two possible filenames 'examplerc' and 'example.rc'...
		strcpy(rcpath+nLen, "BBkeyhookrc");  if (FileExists(rcpath)) break;
		strcpy(rcpath+nLen, "BBkeyhook.rc"); if (FileExists(rcpath)) break;
		if (0 == i)
		{   //...if not found aside the plugin, we keep this as the default path...
			strcpy(defaultpath, rcpath);
			//...and try the Blackbox directory.
			GetBlackboxPath(rcpath, sizeof(rcpath));
			continue;
		}
		//if again no config file was found, we use the default path...
		strcpy(rcpath, defaultpath);
		break; // ...and quit the loop
	}
	// If a config file was found we read the plugin settings from it...
	// ...if not, the ReadXXX functions give us just the defaults.
	config = ReadBool(rcpath, "BBkeyhook.plugin.ConfigMode?:", false);
	volume_step = ReadInt(rcpath, "BBkeyhook.plugin.volumeStep:", 1);
	volume_step = (int)(volume_step * 655.35);
	
	char buffer[MAX_LINE_LENGTH];
	int n = 0;
	for(n = 0; n < 25; n++){
		sprintf(buffer, "BBkeyhook.plugin.key%d:", n);
		keys[n] = ReadInt(rcpath, buffer, -1);
		sprintf(buffer, "BBkeyhook.plugin.scanCode%d:", n);
		codes[n] = ReadInt(rcpath, buffer, -1);
		sprintf(buffer, "BBkeyhook.plugin.command%d:", n);
		strcpy(commands[n], ReadString(rcpath, buffer, ""));
		sprintf(buffer, "BBkeyhook.plugin.argument%d:", n);
		strcpy(arguments[n], ReadString(rcpath, buffer, ""));
	}
}
