/*
 ============================================================================

  This program is free software, released under the GNU General Public License
  (GPL version 2 or later). See for details:

  http://www.fsf.org/licenses/gpl.html

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
  or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
  for more details.

 ============================================================================
*/

#ifdef _MSC_VER
  #ifdef BBOPT_STACKDUMP
    #define TRY if (1)
    #define EXCEPT if(0)
  #else
    #define TRY _try
    #define EXCEPT _except(1)
  #endif
  #define stricmp _stricmp
  #define strnicmp _strnicmp
  #define memicmp _memicmp
  #define strlwr _strlwr
  #define strupr _strupr
  #define strdup _strdup
#else
  #undef BBOPT_STACKDUMP
#endif

#ifndef __BBSLIDESHOW_H
#define __BBSLIDESHOW_H

#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x0501
#endif

#include <windows.h>
#include <commctrl.h>
#include "BBApi.h"
#include "FreeImage.h"

#ifndef SLIT_ADD
#define SLIT_ADD 11001
#endif

#ifndef SLIT_REMOVE
#define SLIT_REMOVE 11002
#endif

#ifndef SLIT_UPDATE
#define SLIT_UPDATE 11003
#endif

#ifndef WS_EX_LAYERED
#define WS_EX_LAYERED	0x00080000
#define LWA_COLORKEY	0x00000001
#define LWA_ALPHA	0x00000002
#endif

#define SLIDESHOW_TIMER 1
#define AUTOHIDE_TIMER 2

#define AUTOHIDE_DELAY 300

//===========================================================================

HINSTANCE hInstance;
HWND hwndPlugin, hwndBlackbox;

bool inSlit = false;
HWND hSlit = NULL;

int msgs[] = {BB_RECONFIGURE, BB_REDRAWGUI, BB_BROADCAST, 0};

char rcpath[MAX_PATH];
char stylepath[MAX_PATH];

int xpos, ypos;
int width, height;
int alpha;
int styleType;
int interval;

bool alwaysOnTop;
bool snapWindow;
bool transparency;
bool pluginToggle;
bool showBorder;
bool allowtip;
bool lockPos;

bool window_test_autohide(POINT *pt);
bool autoHide;
bool is_autohidden;

DWORD justify;
bool usingWin2kXP;
OSVERSIONINFO  osvinfo;

void ShowMyMenu(bool popup);
void ShowFileListMenu(bool popup);

void SetWindowModes(void);
void OnPaint(HWND hwnd);
void OnDropFiles(HDROP);
StyleItem myStyleItem;
int bevelWidth;
int borderWidth;
COLORREF borderColor;

Menu *myMenu, *configSubmenu, *settingsSubmenu,
 *styleSubmenu, *justifySubmenu, *navigateSubmenu, *picSubmenu, *hMenu;

char buf[MAX_LINE_LENGTH] = "no file";
char *szTemp;
char picPath[MAX_LINE_LENGTH];
bool hidden;

int ScreenWidth;
int ScreenHeight;
int newWidth;
int newHeight;

//===========================================================================

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
BOOL WINAPI BBSetLayeredWindowAttributes(HWND hwnd, COLORREF crKey, BYTE bAlpha, DWORD dwFlags);

void GetStyleSettings();
void ReadRCSettings();
void WriteRCSettings();

#define m_alloc(n) malloc(n)
#define c_alloc(n) calloc(1,n)
#define m_free(v) free(v)

HWND hToolTips;
void SetToolTip(RECT *tipRect, char *tipText);
void ClearToolTips(void);
void SetAllowTip(bool);

bool ResizeMyWindow(int newWidth, int newHeight);

//===========================================================================

BOOL LoadPicture(char* szPic);
void ShowCurrentPicture();

FIBITMAP* g_dib=NULL;
BOOL GoPrevPicture();
BOOL GoNextPicture();
void GoFirstPicture();
void GoLastPicture();
void WindowAppendText(HWND hWnd, char* szOut);
BOOL StretchDIB(FIBITMAP* dib, HDC hdc);

bool ProcessMousewheel(POINT pt, bool direction);

int SetDlgCenter(HWND hWnd);
LRESULT CALLBACK    About(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK    MouseProc(int, WPARAM, LPARAM);
static HHOOK        hMouseHook = NULL;
static DWORD        BBThread = 0;
void ShuffleFiles();
BOOL g_bSlideshow = FALSE;
void PrintToPrinter(FIBITMAP* fib);
VOID errhandler(const char* szErr, HWND hwnd);

char szPath[MAX_PATH], szNewName[MAX_PATH];

//===========================================================================

extern "C"
{
	__declspec(dllexport) LPCSTR pluginInfo(int field);
	__declspec(dllexport) void endPlugin(HINSTANCE hMainInstance);
	__declspec(dllexport) int beginPlugin(HINSTANCE hMainInstance);
	__declspec(dllexport) int beginSlitPlugin(HINSTANCE hMainInstance, HWND hBBSlit);
	__declspec(dllexport) int beginPluginEx(HINSTANCE hMainInstance, HWND hBBSlit);
}

//===========================================================================

#endif
