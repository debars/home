/*
 ============================================================================

  This program is free software, released under the GNU General Public License
  (GPL version 2 or later).

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
  or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
  for more details.

  http://www.fsf.org/licenses/gpl.html

 ============================================================================
*/

#include "bbslideshow.h"
#include "resource.h"

char *plugin_info[] =
{
	"BBSlideShow 0.0.6",
	"BBSlideShow",
	"0.0.6",
	"ysuke",
	"2006-03-05",
	"http://zzbb.hp.infoseek.co.jp/",
	"zb2_460@yahoo.co.jp",

	"@BBSlideShowSlideShow"
	"@BBSlideShowGoPrev"
	"@BBSlideShowGoNext"
	"@BBSlideShowGoFirst"
	"@BBSlideShowGoLast"
	"@BBSlideShowShuffle"
	"@BBSlideShowSetPic"
	"@BBSlideShowPicOpen"
	"@BBSlideShowSetWallpaper"
	"@BBSlideShowFileList"
};

#define szVersion       plugin_info[0]
#define szAppName       plugin_info[1]
#define szInfoVersion	plugin_info[2]
#define szInfoAuthor	plugin_info[3]
#define szInfoRelDate	plugin_info[4]
#define szInfoLink	plugin_info[5]
#define szInfoEmail	plugin_info[6]
#define szBroamList	plugin_info[7]


//===========================================================================

// --- based on Bmap ---------------------------------------

void CrackFilename(char* szFile, char** ppNameStart, char** ppExtStart) {
	char* NameStart, *ExtStart;
	NameStart = strrchr(szFile, '\\');
	if(!NameStart) NameStart = szFile;
	else NameStart++;
	if(ppExtStart) {
		ExtStart = strrchr(NameStart, '.');
		if(!ExtStart) ExtStart = NameStart+lstrlen(NameStart);
		*ppExtStart = ExtStart;
	}
	if(ppNameStart)
		*ppNameStart = NameStart;
}

struct FileNode {
	struct FileNode* prev;
	struct FileNode* next;
	char* szName;
	int num;
} *FileList = NULL, *StartFile = NULL, 	**FileArray=NULL;
int FileCount = 0;

void SelectCurrentFile(HWND hwnd) {
	if(FileList && hwnd)
		ListView_SetItemState(hwnd, FileList->num, LVIS_SELECTED, LVIS_SELECTED);
}

void ClearFileList() {
	struct FileNode* fnn;
	struct FileNode* fn = StartFile;
	if(fn)
		do {
			free(fn->szName);
			fnn = fn->next;
			free(fn);
			fn = fnn;
		} while(fn!=StartFile && fn);
	StartFile = NULL;
	FileList = NULL;
	FileCount = 0;
	if(FileArray)
		free(FileArray);
	FileArray = NULL;
}

void AddToFileList(char* szFile) {
	WIN32_FIND_DATA ffd;
	char szPath[MAX_PATH], szNewName[MAX_PATH];
	char *szNameStartF, *szNameStart;

	strcpy(szPath, szFile);
	CrackFilename(szPath, &szNameStart, NULL);
	strcpy(szNameStart, "*.*");
	CrackFilename(szFile, &szNameStart, NULL);
	strcpy(szNewName, szFile);
	CrackFilename(szNewName, &szNameStartF, NULL);

	struct FileNode *FileFirst=NULL;
	HANDLE hFind = FindFirstFile(szPath, &ffd);
	if(hFind != INVALID_HANDLE_VALUE) {
		do {
			if(FreeImage_GetFIFFromFilename(ffd.cFileName) !=FIF_UNKNOWN) {
				struct FileNode *fn;
				fn = (FileNode*)malloc(sizeof(FileNode));
				strcpy(szNameStartF, ffd.cFileName);
				fn->szName = strdup(szNewName);
				fn->prev = FileList;
				fn->next = FileFirst; // circ list: next of last node is first node
				if(FileList)
					FileList->next = fn;
				else
					FileFirst = fn;
				FileList = fn;
				if(stricmp(szNameStart, ffd.cFileName)==0)
					StartFile = fn;
				FileCount++;
			}
		} while(FindNextFile(hFind, &ffd));
		FindClose(hFind);
		if(FileFirst) {
			FileFirst->prev = FileList; // circ list: previous of first node is last node
			FileList = StartFile;

//			FileList->prev->next = NULL; // chop the list
//			FileList->prev = NULL;
		}
		if(!StartFile)
			StartFile=FileFirst;
	}
}

void BuildFileList(char* szFile) {
	ClearFileList();

	AddToFileList(szFile);

	// build array of ptrs for easy random access
	FileArray = (FileNode **)malloc(sizeof(struct FileNode*)*FileCount);
	struct FileNode *fn = StartFile;
	if(fn)
		for(int x=0; x<FileCount; x++) {
			FileArray[x] = fn;
			fn->num = x;
			fn = fn->next;
		}
}

// ---------------------------------------------------------
//===========================================================================

int beginSlitPlugin(HINSTANCE hMainInstance, HWND hBBSlit)
{
	inSlit = true;
	hSlit = hBBSlit;

	// Start the plugin like normal now..
	int res = beginPlugin(hMainInstance);

	// Are we to be in the Slit?
	if (inSlit && hSlit){
		// Yes, so Let's let BBSlit know.
		SendMessage(hSlit, SLIT_ADD, NULL, (LPARAM)hwndPlugin);
	}

	return res;
}

//===========================================================================

int beginPluginEx(HINSTANCE hMainInstance, HWND hBBSlit)
{
	return beginSlitPlugin(hMainInstance, hBBSlit);
}

//===========================================================================

int beginPlugin(HINSTANCE hPluginInstance)
{
	WNDCLASS wc;
	hwndBlackbox = GetBBWnd();
	hInstance = hPluginInstance;

	ZeroMemory(&osvinfo, sizeof(osvinfo));
	osvinfo.dwOSVersionInfoSize = sizeof (osvinfo);
	GetVersionEx(&osvinfo);
	usingWin2kXP =
		osvinfo.dwPlatformId == VER_PLATFORM_WIN32_NT
		&& osvinfo.dwMajorVersion > 4;

	FreeImage_Initialise(FALSE);

	// Register the window class...
	ZeroMemory(&wc,sizeof(wc));
	wc.lpfnWndProc = WndProc; // our window procedure
	wc.hInstance = hPluginInstance; // hInstance of .dll
	wc.lpszClassName = szAppName; // our window class name
	if (!RegisterClass(&wc)) {
		MessageBox(hwndBlackbox, "Error registering window class", szAppName, MB_OK | MB_ICONERROR | MB_TOPMOST);
		return 1;
	}

	ReadRCSettings();
	GetStyleSettings();

	ScreenWidth = GetSystemMetrics(SM_CXVIRTUALSCREEN);
	ScreenHeight = GetSystemMetrics(SM_CYVIRTUALSCREEN);

	// Create the window...
	hwndPlugin = CreateWindowEx(
			usingWin2kXP ? WS_EX_TOOLWINDOW | WS_EX_LAYERED : WS_EX_TOOLWINDOW, // window style
			szAppName, // our window class name
			NULL, // NULL -> does not show up in task manager!
			WS_POPUP | WS_CLIPCHILDREN | WS_CLIPSIBLINGS, // window parameters
			xpos, // x position
			ypos, // y position
			width, // window width
			height, // window height
			NULL, // parent window
			NULL, // no menu
			hPluginInstance, // hInstance of .dll
			NULL);

	if (!hwndPlugin){						   
		MessageBox(0, "Error creating window", szAppName, MB_OK | MB_ICONERROR | MB_TOPMOST);
		// Unregister Blackbox messages...
		SendMessage(hwndBlackbox, BB_UNREGISTERMESSAGE, (WPARAM)hwndPlugin, (LPARAM)msgs);
		return 1;
	}

	// Register to receive Blackbox messages...
	SendMessage(hwndBlackbox, BB_REGISTERMESSAGE, (WPARAM)hwndPlugin, (LPARAM)msgs);
	// Make the window sticky
	MakeSticky(hwndPlugin);
	// Make the window AlwaysOnTop?
	if (alwaysOnTop) SetWindowPos(hwndPlugin, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOACTIVATE | SWP_NOSIZE | SWP_NOMOVE);
	// Make the window autohide?
	is_autohidden = window_test_autohide(NULL);
	SetTimer(hwndPlugin, AUTOHIDE_TIMER, AUTOHIDE_DELAY, NULL);

	SetWindowModes();
        DragAcceptFiles(hwndPlugin, true); // Accept dragged files.

        //-------

	BuildFileList(picPath);
	if(LoadPicture(picPath))
		InvalidateRect(hwndPlugin, NULL, true);

        //-------
	// Show the window and force it to update...
	ShowWindow(hwndPlugin, SW_SHOW);
	InvalidateRect(hwndPlugin, NULL, true);

  	//====================

	INITCOMMONCONTROLSEX ic;
	ic.dwSize = sizeof(INITCOMMONCONTROLSEX);
	ic.dwICC = ICC_BAR_CLASSES;

        if (InitCommonControlsEx(&ic))
        { // Load "tab" controls, including tooltips.
	        hToolTips = CreateWindowEx(
		        WS_EX_TOPMOST,
		        TOOLTIPS_CLASS, // "tooltips_class32"
		        NULL, //"BBSBTT",
		        WS_POPUP | TTS_ALWAYSTIP | TTS_NOPREFIX,
		        CW_USEDEFAULT,
		        CW_USEDEFAULT,
		        CW_USEDEFAULT,
		        CW_USEDEFAULT,
		        NULL,
		        NULL,
		        hPluginInstance,
		        NULL);

	        SendMessage(hToolTips, TTM_SETMAXTIPWIDTH, 0, 300);

	        //SendMessage(hToolTips, TTM_SETDELAYTIME, TTDT_AUTOMATIC, 200);

	        SendMessage(hToolTips, TTM_SETDELAYTIME, TTDT_AUTOPOP, 4000);
	        SendMessage(hToolTips, TTM_SETDELAYTIME, TTDT_INITIAL, 120);
	        SendMessage(hToolTips, TTM_SETDELAYTIME, TTDT_RESHOW,   60);

                if (NULL != hToolTips)
                      SetAllowTip(allowtip);
                else
                      SetAllowTip(false);
	} 
	else
        SetAllowTip(false);

	hMouseHook = SetWindowsHookEx(WH_MOUSE, MouseProc, hPluginInstance, GetCurrentThreadId()); // set hook

  return 0;
}

//===========================================================================

void endPlugin(HINSTANCE hPluginInstance)
{
	// Write the current plugin settings to the config file...
	WriteRCSettings();

	// Release our timer resources
	KillTimer(hwndPlugin, SLIDESHOW_TIMER);
	// Make the window unsticky
	RemoveSticky(hwndPlugin);
	// Unregister Blackbox messages...
	SendMessage(hwndBlackbox, BB_UNREGISTERMESSAGE, (WPARAM)hwndPlugin, (LPARAM)msgs);
	
	if(inSlit && hSlit)
		SendMessage(hSlit, SLIT_REMOVE, NULL, (LPARAM)hwndPlugin);

	ClearToolTips();
  	DestroyWindow(hToolTips);
	// Destroy our window...
	DestroyWindow(hwndPlugin);
	// Unregister window class...
	UnregisterClass(szAppName, hPluginInstance);

	FreeImage_DeInitialise();

	if(hMouseHook) UnhookWindowsHookEx(hMouseHook);    // remove hook
}

//===========================================================================

LPCSTR pluginInfo(int field)
{
	switch (field)
	{
		default:
		case 0: return szVersion;
		case 1: return szAppName;
		case 2: return szInfoVersion;
		case 3: return szInfoAuthor;
		case 4: return szInfoRelDate;
		case 5: return szInfoLink;
		case 6: return szInfoEmail;
		case 7: return szBroamList;
	}
}

//===========================================================================

LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
		case WM_PAINT:
			OnPaint(hwnd);
			break;

		case WM_DROPFILES:
			OnDropFiles((HDROP)wParam);
			break;

		// ==========

		case BB_RECONFIGURE:
		{
			GetStyleSettings();
			InvalidateRect(hwndPlugin, NULL, true);
		}
		break;

		// for bbStylemaker
		case BB_REDRAWGUI:
		{
			GetStyleSettings();
			InvalidateRect(hwndPlugin, NULL, true);
		}
		break;

		// ==========

		case WM_TIMER:
		{
			switch (wParam)
			{
				case SLIDESHOW_TIMER:
				{
					if(FileList)
					{
						if(FileList->next==NULL)
							GoFirstPicture();
						else
							GoNextPicture();
					}
				}
 				break;

				case AUTOHIDE_TIMER:
				{
					bool hide_it = window_test_autohide(NULL);
					if (hide_it)
					{
						POINT pt; RECT rct;
						GetCursorPos(&pt);
						GetWindowRect(hwnd, &rct);
						if (PtInRect(&rct, pt) || (0x8000 & GetKeyState(VK_LBUTTON)))
							break;
					}
					is_autohidden = hide_it;
					KillTimer(hwnd, wParam);

					bool set_pos = false == inSlit;
					POINT pt = { xpos, ypos };
					bool can_hide = window_test_autohide(&pt);

					SetWindowPos(
                                          hwnd,
                                          can_hide || alwaysOnTop ? HWND_TOPMOST : HWND_NOTOPMOST,
                                          pt.x,
                                          pt.y,
                                          width,
                                          height,
                                          set_pos ? SWP_NOACTIVATE|SWP_NOZORDER|SWP_NOSENDCHANGING
                                                  : SWP_NOACTIVATE|SWP_NOZORDER|SWP_NOMOVE|SWP_NOSENDCHANGING);
				}
				break;
			}
		}
		break;

		// ==========

		case WM_DISPLAYCHANGE:
		{
			if(!inSlit)
			{
				// IntelliMove(tm)... <g>
				// (c) 2003 qwilk
				//should make this a function so it can be used on startup in case resolution changed since
				//the last time blackbox was used.
				int relx, rely;
				int oldscreenwidth = ScreenWidth;
				int oldscreenheight = ScreenHeight;
				ScreenWidth = GetSystemMetrics(SM_CXVIRTUALSCREEN);
				ScreenHeight = GetSystemMetrics(SM_CYVIRTUALSCREEN);
				if (xpos > oldscreenwidth / 2)
				{
					relx = oldscreenwidth - xpos;
					xpos = ScreenWidth - relx;
				}
				if (ypos > oldscreenheight / 2)
				{
					rely = oldscreenheight - ypos;
					ypos = ScreenHeight - rely;
				}
				MoveWindow(hwndPlugin, xpos, ypos, width, height, true);
			}
		}
		break;

		//====================

		case BB_BROADCAST:
		{
			szTemp = (char*)lParam;

			if (!_stricmp(szTemp, "@BBShowPlugins") &&  pluginToggle && !inSlit)
			{
				// Show window and force update...
				ShowWindow( hwndPlugin, SW_SHOW);
				InvalidateRect( hwndPlugin, NULL, true);
			}
			else if (!_stricmp(szTemp, "@BBHidePlugins") && pluginToggle && !inSlit)
			{
				// Hide window...
				ShowWindow( hwndPlugin, SW_HIDE);
			}

			//===================

			if (strnicmp(szTemp, "@BBSlideShow", 12))
				return 0;
			szTemp += 12;

			//===================

			if (!_stricmp(szTemp, "About"))
			{
				SendMessage(hwndBlackbox, BB_HIDEMENU, 0, 0);
				DialogBox(hInstance, (LPCTSTR)IDD_ABOUTBOX, hwnd, (DLGPROC)About);
			}

			//===================

			else if (!_strnicmp(szTemp, "StyleType", 9))
			{
				styleType = atoi(szTemp + 10);
				GetStyleSettings();
				InvalidateRect(hwndPlugin, NULL, false);
				ShowMyMenu(false);
			}
			//===================

			else if (!_strnicmp(szTemp, "WidthSize", 9))
			{
				newWidth = atoi(szTemp + 10);
				if(ResizeMyWindow(newWidth, height))
				InvalidateRect(hwndPlugin, NULL, true);
			}
			else if (!_strnicmp(szTemp, "HeightSize", 10))
			{
				newHeight = atoi(szTemp + 11);
 				if(ResizeMyWindow(width, newHeight))
				InvalidateRect(hwndPlugin, NULL, true);
			}

			//===================

			else if (!_stricmp(szTemp, "PluginToggle"))
			{
				pluginToggle = (pluginToggle ? false : true);
				SetWindowModes();
			}
			else if (!_stricmp(szTemp, "OnTop"))
			{
				alwaysOnTop = (alwaysOnTop ? false : true);
				if(!inSlit)SetWindowPos( hwndPlugin,
                                                         alwaysOnTop ? HWND_TOPMOST : HWND_NOTOPMOST,
                                                         0, 0, 0, 0,
                                                         SWP_NOACTIVATE | SWP_NOSIZE | SWP_NOMOVE);

				ShowMyMenu(false);
			}
			else if (!_stricmp(szTemp, "InSlit"))
			{
				if(inSlit && hSlit)
				{
					// We are in the slit, so lets unload and get out..
					SendMessage(hSlit, SLIT_REMOVE, NULL, (LPARAM)hwndPlugin);

					// Here you can move to where ever you want ;)
					SetWindowPos(hwndPlugin, NULL, xpos, ypos, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
					inSlit = false;
					SetWindowModes();
				}
				/* Make sure before you try and load into the slit that you have
				* the HWND of the slit ;)
				*/
				else if(hSlit)
				{
					// (Back) into the slit..
					inSlit = true;
					SetWindowModes();
					SendMessage(hSlit, SLIT_ADD, NULL, (LPARAM)hwndPlugin);
				}
			}
			else if (!_stricmp(szTemp, "Transparent"))
			{
				transparency = (transparency ? false : true);
				SetWindowModes();
			}
			else if (!_strnicmp(szTemp, "AlphaValue", 10))
			{
				alpha = atoi(szTemp + 11);
				SetWindowModes();
			}
			else if (!_stricmp(szTemp, "SnapToEdge"))
			{
				snapWindow = (snapWindow ? false : true);
				ShowMyMenu(false);
			}
			else if (!_stricmp(szTemp, "ShowBorder"))
			{
				showBorder = (showBorder ? false : true);
				InvalidateRect(hwndPlugin, NULL, false);
				ShowMyMenu(false);
			}
			else if (!_stricmp(szTemp, "AllowTip"))
			{
				allowtip = (allowtip ? false : true);
				SetAllowTip(allowtip);
				ShowMyMenu(false);
			}
			else if (!_stricmp(szTemp, "LockPosition"))
			{
				lockPos = (lockPos ? false : true);
				ShowMyMenu(false);
                        }
			else if (!_stricmp(szTemp, "AutoHide"))
			{
				autoHide = (autoHide ? false : true);
				is_autohidden = window_test_autohide(NULL);

				bool set_pos = false == inSlit;
				POINT pt = { xpos, ypos };
				bool can_hide = window_test_autohide(&pt);

				SetWindowPos(
                                          hwnd,
                                          can_hide || alwaysOnTop ? HWND_TOPMOST : HWND_NOTOPMOST,
                                          pt.x,
                                          pt.y,
                                          width,
                                          height,
                                          set_pos ? SWP_NOACTIVATE|SWP_NOZORDER|SWP_NOSENDCHANGING
                                                  : SWP_NOACTIVATE|SWP_NOZORDER|SWP_NOMOVE|SWP_NOSENDCHANGING);
				ShowMyMenu(false);
                        }
			//===================

			else if (!_strnicmp(szTemp, "Interval", 8))
			{
				interval = atoi(szTemp + 9);
			}

			//===================

			else if (!_stricmp(szTemp, "GoPrev"))
			{
				GoPrevPicture();
			}
			else if (!_stricmp(szTemp, "GoNext"))
			{
				GoNextPicture();
			}
                  
 			else if (!_stricmp(szTemp, "GoFirst"))
			{
				GoFirstPicture();
			}
			else if (!_stricmp(szTemp, "GoLast"))
			{
				GoLastPicture();
			}

			else if (!_stricmp(szTemp, "Shuffle"))
			{
				ShuffleFiles();
			}

			else if (!_stricmp(szTemp, "SlideShow"))
			{
				if(g_bSlideshow)
					KillTimer(hwndPlugin, SLIDESHOW_TIMER);
                                else
					SetTimer(hwndPlugin, SLIDESHOW_TIMER, interval * 100, NULL);

				g_bSlideshow = !g_bSlideshow;
				ShowMyMenu(false);
			}

			else if (!_stricmp(szTemp, "SetWallpaper"))
			{
				if(g_dib){
					FreeImage_Save(FIF_BMP, g_dib, "c:\\booger.bmp");
					SystemParametersInfo(SPI_SETDESKWALLPAPER, 0, "c:\\booger.bmp", SPIF_UPDATEINIFILE | SPIF_SENDWININICHANGE);
				}
			}

			else if (!_stricmp(szTemp, "SetPic"))
			{
				OPENFILENAME ofn;
				memset( &ofn, 0, sizeof(OPENFILENAME) );
				ofn.lStructSize= sizeof(OPENFILENAME);
				ofn.lpstrFilter= "all file(*.*)\0*.*\0\0";
				ofn.lpstrFile= picPath;
				ofn.nMaxFile= sizeof(picPath);
				ofn.Flags= OFN_FILEMUSTEXIST | OFN_HIDEREADONLY;

				if( GetOpenFileName(&ofn) == TRUE){
					BuildFileList(picPath);
					if(LoadPicture(picPath))
					    	InvalidateRect(hwndPlugin,NULL,TRUE);
				}
			}
			else if (!_stricmp(szTemp, "PicOpen"))
			{
				if(FileList)BBExecute(GetBBWnd(),
						"open",
						FileList->szName,
						NULL, NULL, SW_SHOWNORMAL, false);
			}
			else if (!_stricmp(szTemp, "FileList"))
			{
				ShowFileListMenu(true);
			}
			else if (!_strnicmp(szTemp, "SelectFile", 10))
			{
				int num = atoi(szTemp + 11);

				if(FileList) {
					FileList = FileArray[num];
 					if(LoadPicture(FileList->szName))
						InvalidateRect(hwndPlugin,NULL,TRUE);
				}
			}

			//===================

			else if (!_stricmp(szTemp, "EditRC"))
			{
				BBExecute(GetDesktopWindow(), NULL, rcpath, NULL, NULL, SW_SHOWNORMAL, false);
			}
			else if (!_stricmp(szTemp, "ReloadSettings"))
			{
				ReadRCSettings();
				GetStyleSettings();

				if(inSlit && hSlit){
					SetWindowModes();
					SendMessage(hSlit, SLIT_UPDATE, NULL, NULL);
				}
				else if(!inSlit || !hSlit)
					SendMessage(hSlit, SLIT_REMOVE, NULL, (LPARAM)hwndPlugin);

				else inSlit = false;
			}
			else if (!_stricmp(szTemp, "SaveSettings"))
			{
				WriteRCSettings();
			}
		}
		break;

		// ==========

		case WM_WINDOWPOSCHANGING:
		{
			if (!inSlit && snapWindow)
			{
				if(IsWindowVisible(hwnd)) SnapWindowToEdge((WINDOWPOS*)lParam, 10, true);
			}
		}
		break;

		// ==========

		// Save window position if it changes...
		case WM_WINDOWPOSCHANGED:
		{
			if(!inSlit && !is_autohidden)
			{
				WINDOWPOS* windowpos = (WINDOWPOS*)lParam;
				xpos = windowpos->x;
				ypos = windowpos->y;

				if(ResizeMyWindow(windowpos->cx, windowpos->cy))
				InvalidateRect(hwndPlugin, NULL, true);
			}
		}
		break;

		// ==========

		case WM_NCHITTEST:
		{
			if (GetKeyState(VK_MENU) & 0xF0 && !lockPos)
				return HTBOTTOMRIGHT;
			else
				return HTCAPTION;
		}
		break;

		case WM_EXITSIZEMOVE:
		{
			is_autohidden = window_test_autohide(NULL);
			SetTimer(hwnd, AUTOHIDE_TIMER, AUTOHIDE_DELAY, NULL);
		}
		break;

		case WM_NCMOUSEMOVE:
		{
			if (is_autohidden)
			{
				is_autohidden = false;
				if (false == inSlit)
				{
					bool set_pos = false == inSlit;
					POINT pt = { xpos, ypos };
					bool can_hide = window_test_autohide(&pt);

					SetWindowPos(
                                          hwnd,
                                          can_hide || alwaysOnTop ? HWND_TOPMOST : HWND_NOTOPMOST,
                                          pt.x,
                                          pt.y,
                                          width,
                                          height,
                                          set_pos ? SWP_NOACTIVATE|SWP_NOZORDER|SWP_NOSENDCHANGING
                                                  : SWP_NOACTIVATE|SWP_NOZORDER|SWP_NOMOVE|SWP_NOSENDCHANGING);

					SetTimer(hwnd, AUTOHIDE_TIMER, AUTOHIDE_DELAY, NULL);
				}
			}
		}
		break;

		case WM_NCLBUTTONDOWN:
		{
			if(!inSlit && !lockPos)
				return DefWindowProc(hwnd,message,wParam,lParam);
			else
				SetForegroundWindow(hSlit);
		}
		break;

		case WM_NCLBUTTONUP: {} break;

		// ==========

		case WM_NCRBUTTONUP:
		{
			ShowMyMenu(true);
		}
		break;

		case WM_NCRBUTTONDOWN: {} break;

		case WM_NCLBUTTONDBLCLK:
		{
			if(g_bSlideshow)
				KillTimer(hwndPlugin, SLIDESHOW_TIMER);
			else
				SetTimer(hwndPlugin, SLIDESHOW_TIMER, interval * 100, NULL);

			g_bSlideshow = !g_bSlideshow;
			ShowMyMenu(false);
 		}
		break;

		//===================

		case WM_NCMBUTTONDBLCLK:
		{
			if(FileList)BBExecute(GetBBWnd(),
						"open",
						FileList->szName,
						NULL, NULL, SW_SHOWNORMAL, false);
 		}
		break;

		case WM_CLOSE:
		{
			return 0;
		}
		break;
 		// ==========
		default:
			return DefWindowProc(hwnd,message,wParam,lParam);
	}
	return 0;
}

//===========================================================================

void ShowMyMenu(bool popup)
{
	navigateSubmenu = MakeNamedMenu("Navigate", "BBSS_Navigate", popup);
  	MakeMenuItem(navigateSubmenu, "SlideShow", "@BBSlideShowSlideShow", g_bSlideshow);
 	MakeMenuItemInt(navigateSubmenu, "Interval (1/10s)", "@BBSlideShowInterval", interval, 1, 1000);
	MakeMenuItem(navigateSubmenu, "File List", "@BBSlideShowFileList", false);
	MakeMenuNOP(navigateSubmenu, NULL);
	MakeMenuItem(navigateSubmenu, "Previous Picture", "@BBSlideShowGoPrev", false);
	MakeMenuItem(navigateSubmenu, "Next Picture", "@BBSlideShowGoNext", false);
	MakeMenuItem(navigateSubmenu, "First Picture", "@BBSlideShowGoFirst", false);
	MakeMenuItem(navigateSubmenu, "Last Picture", "@BBSlideShowGoLast", false);
	MakeMenuItem(navigateSubmenu, "Shuffle Order", "@BBSlideShowShuffle", false);

	picSubmenu = MakeNamedMenu("Picture", "BBSS_Picture", popup);
	MakeMenuItem(picSubmenu, "Browse...", "@BBSlideShowSetPic", false);
	MakeMenuItem(picSubmenu, "Open", "@BBSlideShowPicOpen", false);
	MakeMenuItem(picSubmenu, "Set as Wallpaper", "@BBSlideShowSetWallpaper", false);

	configSubmenu = MakeNamedMenu("Configuration", "BBSS_Config", popup);
 	MakeMenuItemInt(configSubmenu, "Width Size", "@BBSlideShowWidthSize", width, 10, ScreenWidth);
	MakeMenuItemInt(configSubmenu, "Height Size", "@BBSlideShowHeightSize", height, 10, ScreenHeight);
	MakeMenuNOP(configSubmenu, NULL);
	if(hSlit) MakeMenuItem(configSubmenu, "In Slit", "@BBSlideShowInSlit", inSlit);
	MakeMenuItem(configSubmenu, "Plugin Toggle", "@BBSlideShowPluginToggle", pluginToggle);
	MakeMenuItem(configSubmenu, "Always on Top", "@BBSlideShowOnTop", alwaysOnTop);
	MakeMenuItem(configSubmenu, "Transparency", "@BBSlideShowTransparent", transparency);
	MakeMenuItemInt(configSubmenu, "Alpha Value", "@BBSlideShowAlphaValue", alpha, 0, 255);
	MakeMenuItem(configSubmenu, "Snap To Edge", "@BBSlideShowSnapToEdge", snapWindow);
	MakeMenuItem(configSubmenu, "Show Border", "@BBSlideShowShowBorder", showBorder);
	MakeMenuItem(configSubmenu, "Allow Tooltip", "@BBSlideShowAllowTip", allowtip);
	MakeMenuItem(configSubmenu, "Lock Position", "@BBSlideShowLockPosition", lockPos);
	MakeMenuItem(configSubmenu, "Auto Hide", "@BBSlideShowAutoHide", autoHide);

	styleSubmenu = MakeNamedMenu("Style Type", "BBSS_StyleType", popup);
	MakeMenuItem(styleSubmenu, "Toolbar",  "@BBSlideShowStyleType 1", (styleType == 1));
	MakeMenuItem(styleSubmenu, "Button",   "@BBSlideShowStyleType 2", (styleType == 2));
	MakeMenuItem(styleSubmenu, "ButtonP",  "@BBSlideShowStyleType 3", (styleType == 3));
	MakeMenuItem(styleSubmenu, "Label",    "@BBSlideShowStyleType 4", (styleType == 4));
	MakeMenuItem(styleSubmenu, "WinLabel", "@BBSlideShowStyleType 5", (styleType == 5));
	MakeMenuItem(styleSubmenu, "Clock",    "@BBSlideShowStyleType 6", (styleType == 6));

	settingsSubmenu = MakeNamedMenu("Settings", "BBSS_Settings", popup);
	MakeMenuItem(settingsSubmenu, "Edit Settings", "@BBSlideShowEditRC", false);
	MakeMenuItem(settingsSubmenu, "Reload Settings", "@BBSlideShowReloadSettings", false);
	MakeMenuItem(settingsSubmenu, "Save Settings", "@BBSlideShowSaveSettings", false);

	myMenu = MakeNamedMenu("BBSlideShow", "BBSS_Main", popup);
	MakeSubmenu(myMenu, navigateSubmenu, "Navigate");
	MakeSubmenu(myMenu, picSubmenu, "Picture");
	MakeSubmenu(myMenu, configSubmenu, "Configuration");
	MakeSubmenu(myMenu, styleSubmenu, "Style Type");
	MakeSubmenu(myMenu, settingsSubmenu, "Settings");
  	MakeMenuItem(myMenu, "About", "@BBSlideShowAbout", false);
	ShowMenu(myMenu);
}

//===========================================================================

void ShowFileListMenu(bool popup)
{
    	char szTitle[256];
    	sprintf(szTitle, "File listing (%d)", FileCount);

	Menu *main = MakeNamedMenu(szTitle, "BBSS_FileList", popup);

	for (int i = 0; i < FileCount; i++){
    		char buf[256];
		char* szName;
    		CrackFilename(FileArray[i]->szName, &szName, NULL);

    		sprintf(buf, "@BBSlideShowSelectFile %d", i);
    		MakeMenuItem(main, szName, buf, !_stricmp(FileArray[i]->szName, FileList->szName));
	}
	ShowMenu(main);
}

//===========================================================================

void GetStyleSettings()
{
	bevelWidth  = *(int*)GetSettingPtr(SN_BEVELWIDTH);
	borderWidth = *(int*)GetSettingPtr(SN_BORDERWIDTH);
	borderColor = *(COLORREF*)GetSettingPtr(SN_BORDERCOLOR);

	myStyleItem = *(StyleItem*)GetSettingPtr(styleType);

	ShowMyMenu(false);
}

//===========================================================================

void ReadRCSettings()
{
	char temp[MAX_LINE_LENGTH], path[MAX_LINE_LENGTH], defaultpath[MAX_LINE_LENGTH];
	int nLen;

	// First we look for the config file in the same folder as the plugin...
	GetModuleFileName(hInstance, rcpath, sizeof(rcpath));
	nLen = strlen(rcpath) - 1;
	while (nLen >0 && rcpath[nLen] != '\\') nLen--;
	rcpath[nLen + 1] = 0;
	strcpy(temp, rcpath);
	strcpy(path, rcpath);
	strcat(temp, "bbslideshow.rc");
	strcat(path, "bbslideshowrc");
	// ...checking the two possible filenames bbslideshow.rc and bbslideshowrc ...
	if (FileExists(temp)) strcpy(rcpath, temp);
	else if (FileExists(path)) strcpy(rcpath, path);
	// ...if not found, we try the Blackbox directory...
	else
	{
		// ...but first we save the default path (bbslideshow.rc in the same
		// folder as the plugin) just in case we need it later (see below)...
		strcpy(defaultpath, temp);
		GetBlackboxPath(rcpath, sizeof(rcpath));
		strcpy(temp, rcpath);
		strcpy(path, rcpath);
		strcat(temp, "bbslideshow.rc");
		strcat(path, "bbslideshowrc");
		if (FileExists(temp)) strcpy(rcpath, temp);
		else if (FileExists(path)) strcpy(rcpath, path);
		else // If no config file was found, we use the default path and settings, and return
		{
			strcpy(rcpath, defaultpath);
			xpos = ypos = 10;
			width = 140;
			height =100;
			alpha = 160;
			styleType = 1;
			interval = 10;
			alwaysOnTop = false;
			transparency = false;
			snapWindow = true;
			pluginToggle = false;
			inSlit = false;
			showBorder = true;
			allowtip = true;
			lockPos = false;
			autoHide = false;
			WriteRCSettings(); //write a file for editing later
			return;
		}
	}

	// If a config file was found we read the plugin settings from the file...
	xpos = ReadInt(rcpath, "bbslideshow.x:", 10);
	ypos = ReadInt(rcpath, "bbslideshow.y:", 10);
	if (xpos >= GetSystemMetrics(SM_CXVIRTUALSCREEN)) xpos = 10;
	if (ypos >= GetSystemMetrics(SM_CYVIRTUALSCREEN)) ypos = 10;
	width = ReadInt(rcpath, "bbslideshow.width:", 140);
	height = ReadInt(rcpath, "bbslideshow.height:", 100);
	alpha = ReadInt(rcpath, "bbslideshow.alpha:", 160);
	styleType = ReadInt(rcpath, "bbslideshow.styleType:", 1);
 	interval = ReadInt(rcpath, "bbslideshow.interval(1/10s):", 10);
	alwaysOnTop = ReadBool(rcpath, "bbslideshow.alwaysontop:", false);
	transparency = ReadBool(rcpath, "bbslideshow.transparency:", false);
	snapWindow = ReadBool(rcpath, "bbslideshow.snapwindow:", true);
	pluginToggle = ReadBool(rcpath, "bbslideshow.pluginToggle:", false);
	inSlit = ReadBool(rcpath, "bbslideshow.inSlit:", false);
	showBorder = ReadBool(rcpath, "bbslideshow.showBorder:", true);
	allowtip = ReadBool(rcpath, "bbslideshow.allowtooltip:", true);
	lockPos = ReadBool(rcpath, "bbslideshow.lockPos:", false);
	autoHide = ReadBool(rcpath, "bbslideshow.autoHide:", false);
	strcpy(picPath, ReadString(rcpath, "bbslideshow.picPath:", ""));
}

//===========================================================================

void WriteRCSettings()
{
	WriteInt(rcpath, "bbslideshow.x:", xpos);
	WriteInt(rcpath, "bbslideshow.y:", ypos);
	WriteInt(rcpath, "bbslideshow.width:", width);
	WriteInt(rcpath, "bbslideshow.height:", height);
	WriteInt(rcpath, "bbslideshow.alpha:", alpha);
	WriteInt(rcpath, "bbslideshow.styleType:", styleType);
	WriteInt(rcpath, "bbslideshow.interval(1/10s):", interval);
	WriteBool(rcpath, "bbslideshow.alwaysontop:", alwaysOnTop);
	WriteBool(rcpath, "bbslideshow.transparency:", transparency);
	WriteBool(rcpath, "bbslideshow.snapWindow:", snapWindow);
	WriteBool(rcpath, "bbslideshow.pluginToggle:", pluginToggle);
	WriteBool(rcpath, "bbslideshow.inSlit:", inSlit);
	WriteBool(rcpath, "bbslideshow.showBorder:", showBorder);
	WriteBool(rcpath, "bbslideshow.allowtooltip:", allowtip);
	WriteBool(rcpath, "bbslideshow.lockPos:", lockPos);
	WriteBool(rcpath, "bbslideshow.autoHide:", autoHide);
	if(FileList) WriteString(rcpath, "bbslideshow.picPath:", FileList->szName);
}

//=========================================================================

void SetWindowModes(void)
{
	if(usingWin2kXP){
		if(!inSlit){
			// Add the WS_EX_LAYERED atribute to the window.
			SetWindowLong(hwndPlugin, GWL_EXSTYLE , GetWindowLong(hwndPlugin, GWL_EXSTYLE) | WS_EX_LAYERED);
			// Make it transparent...
			BBSetLayeredWindowAttributes(hwndPlugin, NULL, (transparency) ? (unsigned char)alpha : 255, LWA_ALPHA);
		}else{
			// Remove the WS_EX_LAYERED atribute to the window, cos we in di slit!
			SetWindowLong(hwndPlugin, GWL_EXSTYLE, GetWindowLong(hwndPlugin, GWL_EXSTYLE) & ~WS_EX_LAYERED);
		}
	}
	InvalidateRect(hwndPlugin, NULL, false);
	ShowMyMenu(false);
}

//=========================================================================

void OnPaint(HWND hwnd)
{
	// Create buffer hdc's, bitmaps etc.
	PAINTSTRUCT ps;  RECT r;

	//get screen buffer
	HDC hdc_scrn = BeginPaint(hwnd, &ps);

	//get window rectangle.
	GetClientRect(hwnd, &r);

	//first get a new 'device context'
	HDC hdc = CreateCompatibleDC(NULL);

	//then create a buffer in memory with the window size
	HBITMAP bufbmp = CreateCompatibleBitmap(hdc_scrn, r.right, r.bottom);

	//select the bitmap into the DC
	HGDIOBJ otherbmp = SelectObject(hdc, bufbmp);


	MakeStyleGradient(hdc, &r, &myStyleItem, showBorder);

	SetToolTip(&r, buf);

	// Finally, copy from the paint buffer to the window...
	BitBlt(hdc_scrn, 0, 0, width, height, hdc, 0, 0, SRCCOPY);

	StretchDIB(g_dib, ps.hdc);

	// Remember to delete all objects!
	DeleteObject(SelectObject(hdc, otherbmp));
	DeleteDC(hdc);

	EndPaint(hwnd, &ps);
}

//=========================================================================

//so there you just use BBSLWA like normal SLWA
//(c)grischka
BOOL WINAPI BBSetLayeredWindowAttributes(HWND hwnd, COLORREF crKey, BYTE bAlpha, DWORD dwFlags)
{
	static BOOL (WINAPI *pSLWA)(HWND, COLORREF, BYTE, DWORD);
	static int f=0;
	for (;;) {
		if (2==f)   return pSLWA(hwnd, crKey, bAlpha, dwFlags);
		// if it's not there, just do nothing and report success
		if (f)      return TRUE;
		*(FARPROC*)&pSLWA = GetProcAddress(GetModuleHandle("USER32"), "SetLayeredWindowAttributes");
		f = pSLWA ? 2 : 1;
	}
}

//=========================================================================

bool ResizeMyWindow(int newWidth, int newHeight)
{
	if(newWidth != width || newHeight != height){
		width = newWidth;
		height = newHeight;
		if (width <= 10)  width  = 10;
		if (height <= 10) height = 10;
	}
	else
		return false;

	if(inSlit){
		SetWindowPos(hwndPlugin, 0, 0, 0, width, height, SWP_NOACTIVATE | SWP_NOZORDER | SWP_NOMOVE);
		SendMessage(hSlit, SLIT_UPDATE, NULL, NULL);
		return true;
	}else{
		SetWindowPos(hwndPlugin, 0, xpos, ypos, width, height, SWP_NOACTIVATE | SWP_NOZORDER);
		return true;
	}
}

//=========================================================================

bool ProcessMousewheel(POINT pt, bool direction)
{
	RECT r;
	GetWindowRect(hwndPlugin, &r);
	if (PtInRect(&r, pt)){
		(direction) ? GoNextPicture() : GoPrevPicture();
		return true;
	}
	return false;
}

LRESULT CALLBACK MouseProc(int nCode, WPARAM wParam, LPARAM lParam)
{
	if (nCode >= 0) switch (wParam){
		case WM_MOUSEWHEEL:
		{
            		if(usingWin2kXP){
            			MOUSEHOOKSTRUCTEX *pData = (MOUSEHOOKSTRUCTEX*)lParam;
            			if (ProcessMousewheel(pData->pt, ((short)HIWORD(pData->mouseData) < 0)))
            			return 1;
            		}else{
            			MOUSEHOOKSTRUCT *pData = (MOUSEHOOKSTRUCT*)lParam;
            			if (ProcessMousewheel(pData->pt, ((short)LOWORD(pData->dwExtraInfo) < 0)))
            			return 1;
            		}
            		break;
		}
	}
	return CallNextHookEx(hMouseHook, nCode, wParam, lParam);
}

//===========================================================================
//get_monitor - multimon api, win 9x compatible

static HMONITOR (WINAPI *pMonitorFromWindow)(HWND hwnd, DWORD dwFlags);
static BOOL     (WINAPI *pGetMonitorInfoA)(HMONITOR hMonitor, LPMONITORINFO lpmi);

HMONITOR get_monitor(HWND hw)
{
	if (NULL == pMonitorFromWindow)
	{
		HMODULE hDll = GetModuleHandle("USER32");
		*(FARPROC*)&pMonitorFromWindow = GetProcAddress(hDll, "MonitorFromWindow" );
		*(FARPROC*)&pGetMonitorInfoA   = GetProcAddress(hDll, "GetMonitorInfoA"   );
		if (NULL == pMonitorFromWindow)
			*(int*)&pMonitorFromWindow = 1;
	}

	if (*(DWORD*)&pMonitorFromWindow <= 1)
		return NULL;

	return pMonitorFromWindow(hw, MONITOR_DEFAULTTOPRIMARY);
}

//===========================================================================
//get_mon_rect

void get_mon_rect(HMONITOR hMon, RECT *r)
{
	if (hMon)
	{
		MONITORINFO mi;
		mi.cbSize = sizeof(mi);
		if (pGetMonitorInfoA(hMon, &mi))
		{
			*r = mi.rcMonitor;
			//*r = mi.rcWork;
			return;
		}
	}
	//SystemParametersInfo(SPI_GETWORKAREA, 0, r, 0);
	r->top = r->left = 0;
	r->right = GetSystemMetrics(SM_CXSCREEN);
	r->bottom = GetSystemMetrics(SM_CYSCREEN);
}

//===========================================================================

bool window_test_autohide(POINT *pt)
{
	if (false == autoHide || inSlit)
		return false;

	int x = xpos;
	int y = ypos;

	RECT scrn;
	get_mon_rect(get_monitor(hwndPlugin), &scrn);

	if (x == scrn.left) x = 1-width;
	else
	if (x == scrn.right - width) x = scrn.right - 1;
	else
	if (y == scrn.top) y = 1 - height;
	else
	if (y == scrn.bottom - height) y = scrn.bottom - 1;
	else
		return false;

	if (pt && is_autohidden)
		pt->x = x, pt->y = y;

	return true;
}

//===========================================================================

struct tt
{
	struct tt *next;
	char used_flg;
	char text[1024];
	TOOLINFO ti;
} *tt0;

void SetToolTip(RECT *tipRect, char *tipText)
{
	if (NULL==hToolTips) return;

	struct tt **tp, *t; unsigned n=0;
	for (tp=&tt0; NULL!=(t=*tp); tp=&t->next){
		if (0==memcmp(&t->ti.rect, tipRect, sizeof(RECT))){
			t->used_flg = 1;
			if (0!=strcmp(t->ti.lpszText, tipText)){
				strcpy(t->text, tipText);
				SendMessage(hToolTips, TTM_UPDATETIPTEXT, 0, (LPARAM)&t->ti);
			}
			return;
		}
		if (t->ti.uId > n)
			n = t->ti.uId;
	}

	t = (struct tt*)c_alloc(sizeof (*t));
	t->used_flg  = 1;
	t->next = NULL;
	strcpy(t->text, tipText);
	*tp = t;

	memset(&t->ti, 0, sizeof(TOOLINFO));

	t->ti.cbSize   = sizeof(TOOLINFO);
	t->ti.uFlags   = TTF_SUBCLASS;
	t->ti.hwnd     = hwndPlugin;
	t->ti.uId      = n+1;
	//t->ti.hinst    = NULL;
	t->ti.lpszText = t->text;
	t->ti.rect     = *tipRect;

	SendMessage(hToolTips, TTM_ADDTOOL, 0, (LPARAM)&t->ti);
}

void ClearToolTips(void)
{
	struct tt **tp, *t;
	tp=&tt0; while (NULL!=(t=*tp)){
		if (0==t->used_flg){
			SendMessage(hToolTips, TTM_DELTOOL, 0, (LPARAM)&t->ti);
			*tp=t->next;
			m_free(t);
		}else{
			t->used_flg = 0;
			tp=&t->next;
		}
	}
}

void SetAllowTip(bool allowtip)
{
	if (NULL != hToolTips){
		SendMessage(hToolTips, TTM_ACTIVATE, (WPARAM)allowtip, 0);
	}else{
		SendMessage(hToolTips, TTM_ACTIVATE, (WPARAM)false, 0);
	}
}

//===========================================================================

// --- based on Bmap ---------------------------------------

FIBITMAP* MyFreeImage_Load(char* szPic) {
	FREE_IMAGE_FORMAT fif = FreeImage_GetFIFFromFilename(szPic);
	if(fif!=FIF_UNKNOWN)
		return FreeImage_Load(fif, szPic);
	else
		return NULL;
}

BOOL StretchDIB(FIBITMAP* dib, HDC hdc) {
	if(hdc && dib) {
		RECT rect;
		GetClientRect(hwndPlugin, &rect);
		unsigned int p_width = rect.right-rect.left;
		unsigned int p_height = rect.bottom-rect.top;
                int gap = bevelWidth + borderWidth;

		if(width-FreeImage_GetWidth(dib) > 2 || height-FreeImage_GetHeight(dib) > 2) {
			unsigned int left = 0;
			unsigned int top = 0;
			float ar = (float)FreeImage_GetWidth(dib) / (float)FreeImage_GetHeight(dib);

			if(p_width/ar < p_height) {
				p_height = (int)(p_width / ar);
				top = (rect.bottom-rect.top-p_height)/2;
			}	else {
				p_width = (int)(p_height * ar);
				left = (rect.right-rect.left-p_width)/2;
			}

			SetStretchBltMode(hdc, HALFTONE );
			StretchDIBits(hdc, left+gap, top+gap, p_width-gap*2, p_height-gap*2,
											 0, 0, FreeImage_GetWidth(dib), FreeImage_GetHeight(dib),
											 FreeImage_GetBits(dib), FreeImage_GetInfo(dib), DIB_RGB_COLORS, SRCCOPY);
		} else
			SetDIBitsToDevice(hdc, 0, 0, FreeImage_GetWidth(dib),
				FreeImage_GetHeight(dib), 0, 0, 0,
				FreeImage_GetHeight(dib), FreeImage_GetBits(dib),
				FreeImage_GetInfo(dib), DIB_RGB_COLORS); 

	}
	return(hdc&&dib);
}

BOOL LoadPicture(char* szPic) {

	if(!*szPic)
		return FALSE;

	DWORD dwStart = GetTickCount();

	if(g_dib)
		FreeImage_Unload(g_dib);
	g_dib=NULL;
	FIBITMAP* dib = MyFreeImage_Load(szPic);
	if(!dib) {
		wsprintf(buf, "Error loading: %s", szPic);

		return FALSE;
	}

	g_dib = dib;

	DWORD dwTotal = GetTickCount()-dwStart;

	char* szJustFile;
	CrackFilename(szPic, &szJustFile, NULL);
	wsprintf(buf, "%s - %dms", szJustFile, dwTotal);

	ShowFileListMenu(false);

	return TRUE;
}

void OnDropFiles(HDROP hDrop) {
	DragQueryFile(hDrop, 0, picPath, sizeof(picPath));
	BuildFileList(picPath);
	if(LoadPicture(picPath))
		InvalidateRect(hwndPlugin,NULL,TRUE);
}

BOOL GoNextPicture() {
	if(FileList && FileList->next) {
		FileList = FileList->next;
		if(LoadPicture(FileList->szName))
			InvalidateRect(hwndPlugin,NULL,TRUE);
		return TRUE;
	}
	return FALSE;
}

BOOL GoPrevPicture() {
	if(FileList && FileList->prev) {
		FileList = FileList->prev;
		if(LoadPicture(FileList->szName))
			InvalidateRect(hwndPlugin,NULL,TRUE);
		return TRUE;
	}
	return FALSE;
}

void GoFirstPicture() {
	if(FileList) {
		FileList = FileArray[0];
		if(LoadPicture(FileList->szName))
			InvalidateRect(hwndPlugin,NULL,TRUE);
	}
}

void GoLastPicture() {
	if(FileList) {
		FileList = FileArray[FileCount-1];
		if(LoadPicture(FileList->szName))
			InvalidateRect(hwndPlugin,NULL,TRUE);
	}
}

void ShuffleFiles() {
	char* szOrgName = FileList->szName;

	srand(GetTickCount());
	char* szTemp;
	int r;
	for(int x=0; x<FileCount*7; x++) { // 7 shuffles for a good, lucky feeling
		r = rand()%FileCount;
		szTemp = FileArray[x%FileCount]->szName;
		FileArray[x%FileCount]->szName = FileArray[r]->szName;
		FileArray[r]->szName = szTemp;
		if(FileArray[x%FileCount]->szName==szOrgName)
			FileList = FileArray[x%FileCount];
		if(FileArray[r]->szName==szOrgName)
			FileList = FileArray[r];
	}
}


int SetDlgCenter(HWND hWnd)
{
    HWND hDeskWnd;
    RECT deskrc, rc;
    int x, y;

    hDeskWnd = GetDesktopWindow();
    GetWindowRect(hDeskWnd, (LPRECT)&deskrc);
    GetWindowRect(hWnd, (LPRECT)&rc);
    x = (deskrc.right - (rc.right - rc.left)) / 2;
    y = (deskrc.bottom - (rc.bottom - rc.top)) / 2;
    SetWindowPos(hWnd, HWND_TOP, x, y, (rc.right - rc.left), (rc.bottom - rc.top), SWP_SHOWWINDOW); 
    return 0;
}

// Mesage handler for about box.
LRESULT CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
		case WM_INITDIALOG: {
			char blah[16384];
			blah[0]=0;
			int count = FreeImage_GetFIFCount();
			for(int x=0; x<count; x++) {
				FREE_IMAGE_FORMAT fif = (FREE_IMAGE_FORMAT)x;
				if(FreeImage_FIFSupportsReading(fif)) {
					wsprintf(blah+strlen(blah), "%s\t%s\r\n",
					FreeImage_GetFIFExtensionList(fif),
					FreeImage_GetFIFDescription(fif) );
				}
			}
			UINT tstop = 40;
			SendMessage(GetDlgItem(hDlg, IDC_FORMATS), EM_SETTABSTOPS, 1, (LPARAM)&tstop);
			SetDlgItemText(hDlg, IDC_FORMATS, blah);

			SetDlgItemText(hDlg, IDC_FIVERSION, FreeImage_GetVersion());
			SetDlgCenter(hDlg);
			MessageBeep(MB_OK);
			return TRUE;
		}

		case WM_COMMAND:
			if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL) {
				EndDialog(hDlg, LOWORD(wParam));
				return TRUE;
			}
	}
	return FALSE;
}

// ---------------------------------------------------------