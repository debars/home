/*---------------------------------------------------------------------------------
 BroamTimer (� 2004 Slade Taylor [bladestaylor@yahoo.com])
 ----------------------------------------------------------------------------------
 BroamTimer is a plugin for Blackbox for Windows.  For more information,
 please visit [http://bb4win.org] or [http://sourceforge.net/projects/bb4win].
 ----------------------------------------------------------------------------------
 BroamTimer is free software, released under the GNU General Public License,
 version 2, as published by the Free Software Foundation.  It is distributed
 WITHOUT ANY WARRANTY--without even the implied warranty of MERCHANTABILITY
 or FITNESS FOR A PARTICULAR PURPOSE.  Please see the GNU General Public
 License for more details:  [http://www.fsf.org/licenses/gpl.html].
 --------------------------------------------------------------------------------*/

#include "BroamTimer.h"

//-------------------------------------------------------------------------------------

int beginPlugin(HINSTANCE hPluginInstance)
{
    WNDCLASS wc;
    ZeroMemory((void*)&wc, sizeof(wc));
    wc.lpszClassName = pluginInfo(APPNAME);
    wc.hInstance = hPluginInstance;
    wc.lpfnWndProc = PluginProc;
    RegisterClass(&wc);

    hPluginWnd = CreateWindowEx(
        WS_EX_TOOLWINDOW,
        pluginInfo(APPNAME),
        NULL,
        WS_POPUP,
        0, 0, 0, 0,
        HWND_MESSAGE,
        NULL,
        hPluginInstance,
        NULL
    );

    SendMessage(hCoreWnd = GetBBWnd(), BB_REGISTERMESSAGE, (WPARAM)hPluginWnd, (LPARAM)bb_messages);

    const int i = GetModuleFileName(hPluginInstance, RC_Path, MAX_LINE_LENGTH);
    strcpy(Broam_Path, RC_Path);
    strcpy(Broam_Path + i - 14, "Broams.rc");
    if (i > 3) { RC_Path[i - 3] = 'r'; RC_Path[i - 2] = 'c'; RC_Path[i - 1] = 0; }

    if (RCSettings())
        TimerObject.Set();
    return 0;
}

//-------------------------------------------------------------------------------------

void endPlugin(HINSTANCE hPluginInstance)
{
    SendMessage(hCoreWnd, BB_UNREGISTERMESSAGE, (WPARAM)hPluginWnd, (LPARAM)bb_messages);
    DestroyWindow(hPluginWnd);
    UnregisterClass(pluginInfo(APPNAME), hPluginInstance);
    TimerObject.Kill();
    if (pBroamItem)
        delete pBroamItem;
}

//-------------------------------------------------------------------------------------

LRESULT CALLBACK PluginProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)
    {
        case WM_TIMER:
            TimerObject.Timer();
            break;

        case BB_BROADCAST:
            TimerObject.Broam((char*)lParam);
            break;

        case BB_RECONFIGURE:
            TimerObject.Reconfigure();
            break;

        default:
            return DefWindowProc(hwnd, message, wParam, lParam);
    }
    return 0;
}

//-------------------------------------------------------------------------------------

void TimerItem::Set()
{
    if (m_current_item)
    {
        SetTimer(hPluginWnd, TIMER_ID, m_interval, false);
        m_enabled = true;
    }
}

//-------------------------------------------------------------------------------------

void TimerItem::Kill()
{
    KillTimer(hPluginWnd, TIMER_ID);
    m_enabled = false;
}

//-------------------------------------------------------------------------------------

void TimerItem::Timer()
{
    PostMessage(hCoreWnd, BB_BROADCAST, NULL, (LPARAM)m_current_item->m_txt);
    m_current_item = m_current_item->m_next ? m_current_item->m_next: pBroamItem;
}

//-------------------------------------------------------------------------------------

void TimerItem::Reconfigure()
{
    if (RCSettings())
        Set();
    else
        Kill();
}

//-------------------------------------------------------------------------------------

void TimerItem::Broam(char *broam_txt)
{
    if (_strnicmp(broam_txt, "@BroamTimer.", 12))
        return;
    broam_txt += 12;
    //--------------------------------------
    if (!_stricmp(broam_txt, "Play"))
    {
        m_current_item = pBroamItem;
        goto tmr_set;
    }
    //--------------------------------------
    else if (!_stricmp(broam_txt, "Stop"))
    {
        m_current_item = pBroamItem;
        goto tmr_kill;
    }
    //--------------------------------------
    else if (!_stricmp(broam_txt, "Resume"))
    {
        goto tmr_set;
    }
    //--------------------------------------
    else if (!_stricmp(broam_txt, "Pause"))
    {
        goto tmr_kill;
    }
    //--------------------------------------
    /*
    else if (!_strnicmp(broam_txt, "Interval.", 9))
    {
        m_interval = atoi(broam_txt += 9);
        goto br_rc;
    }
    */
    //--------------------------------------
    else if (!_stricmp(broam_txt, "Read"))
    {
        if (RCSettings() && m_enabled)
            goto tmr_set;
        goto tmr_kill;
    }
    //--------------------------------------
    else if (!_stricmp(broam_txt, "Toggle"))
    {
        if (m_enabled)
tmr_kill:   Kill();
        else
tmr_set:    Set();
    }
    //--------------------------------------
}

#if 0

@BroamTimer.Play
@BroamTimer.Stop
@BroamTimer.Pause
@BroamTimer.Resume
//@BroamTimer.Interval.1000
@BroamTimer.Toggle
@BroamTimer.Read

#endif

//-------------------------------------------------------------------------------------

/*--------------------------------------------------
  FileRead if part of the bbLean source code
  � 2004 grischka [grischka@users.sourceforge.net]
/*--------------------------------------------------*/

bool L_FileRead(FILE *f, LPSTR string)
{
    *string=0;
    if (NULL==f||NULL==fgets(string, 256, f))
        return false;
    int l = strlen(string);
    while (l && (unsigned char)string[l-1]<=32) l--; // skip trailing stuff
    string[l]=0;
    while (l--) if (string[l]==9) string[l]=32; // replace tabs
    return true;
}

//-------------------------------------------------------------------------------------

bool RCSettings()
{
    //RC_String(    "Window.Name:", WindowName,         "BBInterface",      MAX_LINE_LENGTH - 1);
    RC_Int(     "Interval:",    &TimerObject.m_interval,        2000);

    //------------------------------------------

    char *p_buf, buf[BroamItem::MAX_BROAM_LENGTH];
    buf[0] = 0;

    TimerObject.m_current_item = NULL;

    if (pBroamItem)
    {
        delete pBroamItem;
        pBroamItem = NULL;
    }

    FILE *f = NULL;
    if (f = fopen(Broam_Path, "rt"))
        goto readf;

    f = fopen(Broam_Path, "wt");
    if (!f) return false;
    fprintf(f, "! Enter bro@ms here--one per line."
        "\n\n! @BBShowPlugins"
        "\n! @BBHidePlugins"
        );
    fclose(f);

    if (f = fopen(Broam_Path, "rt"))
    {
readf:  BroamItem *p = NULL;
        while (L_FileRead(f, p_buf = buf))
        {
            while (isspace(*p_buf) && *p_buf) ++p_buf;
            if (*p_buf && (*p_buf != '#') && (*p_buf != '!'))
            {
                if (pBroamItem)
                {
                    p->m_next = new BroamItem(p_buf);
                    p = p->m_next;
                }
                else
                {
                    pBroamItem = new BroamItem(p_buf);
                    p = pBroamItem;
                }
            }
        }
        fclose(f);
    }

    TimerObject.m_current_item = pBroamItem;
    return pBroamItem != NULL;
}

//-------------------------------------------------------------------------------------

void RC_Int(char *label, int *target, int default_val)
{
    *target = ReadInt(RC_Path, label, default_val);
    WriteInt(RC_Path, label, *target);
}

//-------------------------------------------------------------------------------------

void RC_String(char *label, char *target, char *default_val, int max_len)
{
    strncpy(target, ReadString(RC_Path, label, default_val), max_len);
    target[max_len] = 0;
    WriteString(RC_Path, label, target);
}

//-------------------------------------------------------------------------------------
