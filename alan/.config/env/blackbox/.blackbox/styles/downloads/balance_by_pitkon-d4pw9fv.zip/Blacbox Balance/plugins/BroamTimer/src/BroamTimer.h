/*---------------------------------------------------------------------------------
 BroamTimer (� 2004 Slade Taylor [bladestaylor@yahoo.com])
 ----------------------------------------------------------------------------------
 BroamTimer is a plugin for Blackbox for Windows.  For more information,
 please visit [http://bb4win.org] or [http://sourceforge.net/projects/bb4win].
 ----------------------------------------------------------------------------------
 BroamTimer is free software, released under the GNU General Public License,
 version 2, as published by the Free Software Foundation.  It is distributed
 WITHOUT ANY WARRANTY--without even the implied warranty of MERCHANTABILITY
 or FITNESS FOR A PARTICULAR PURPOSE.  Please see the GNU General Public
 License for more details:  [http://www.fsf.org/licenses/gpl.html].
 --------------------------------------------------------------------------------*/

#ifndef _WIN32_WINNT
    #define _WIN32_WINNT 0x0500
#endif

#define VC_EXTRALEAN

#include "../bbLean/BBApi.h"
#include <stdlib.h>

//-------------------------------------------------------------------------------------

enum PLUGIN_INFO { NAME_VERSION = 0, APPNAME, VERSION, AUTHOR, RELEASEDATE, WEBLINK, EMAIL };

extern "C"
{
    __declspec(dllexport) void      endPlugin(HINSTANCE);
    __declspec(dllexport) int       beginPlugin(HINSTANCE);

    __declspec(dllexport) LPCSTR    pluginInfo(int x)
    {
        switch (x)
        {
            case APPNAME:       return "BroamTimer";
            case VERSION:       return "0.0.1";
            case AUTHOR:        return "bladestaylor";
            case RELEASEDATE:   return "May 17, 2004";
            case WEBLINK:       return "http://bb4win.sourceforge.net/bladestaylor/";
            case EMAIL:         return "bladestaylor@yahoo.com";
            default:            return "BroamTimer 0.0.1";
        }
    };
}

//---------------------------------------------------------------------------------

class BroamItem
{
public:
    BroamItem(char *txt)
    {
        strcpy(m_txt, txt);
        m_next = NULL;
    };

    ~BroamItem() { if (m_next) delete m_next; };

    static const int MAX_BROAM_LENGTH = 2048;
    char m_txt[MAX_BROAM_LENGTH];
    BroamItem *m_next;
};

BroamItem   *pBroamItem = NULL;

//---------------------------------------------------------------------------------

class TimerItem
{
public:
    void Set();
    void Kill();
    void Timer();
    void Broam(char*);
    void Reconfigure();

    static const int TIMER_ID = 1;
    BroamItem   *m_current_item;
    int         m_interval;
    bool        m_enabled;
};

TimerItem TimerObject;

//---------------------------------------------------------------------------------

LRESULT CALLBACK    PluginProc(HWND, UINT, WPARAM, LPARAM);
void                RC_String(char*, char*, char*, int);
void                RC_Int(char*, int*, int);
bool                L_FileRead(FILE*, LPSTR);
bool                RCSettings();

//---------------------------------------------------------------------------------

int bb_messages[] = {BB_RECONFIGURE, BB_BROADCAST, 0};

HWND        hCoreWnd = NULL,
            hPluginWnd = NULL;
char        RC_Path[MAX_LINE_LENGTH];
char        Broam_Path[MAX_LINE_LENGTH];
char        WindowName[MAX_LINE_LENGTH];

//---------------------------------------------------------------------------------