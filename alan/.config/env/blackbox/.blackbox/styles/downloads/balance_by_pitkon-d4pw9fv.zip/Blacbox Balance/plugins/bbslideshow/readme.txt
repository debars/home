BBSlideShow is a plugin for Blackbox for Windows.

The main function of this plugin is based on the open source image viewer Bmap version 0.9.3.
Bmap http://dana.ucc.nau.edu/~tsr22/apps/#bmap


This plugin needs the Freeimage.dll to run.
Download the FreeImage.dll from http://freeimage.sourceforge.net/download.html.
And copy it to the same directory as blackbox.exe.


Mouse Controls:
Right Click                   Configuration Menu
Left Click & Drag             Move
Alt + Left Click & Drag       Resize
Double Left Click             SlideShow Start/Stop
Double Middle Click           Open Current Picture File
Drop on BBSlideShow           Set as Current Picture
MouseWheel Down               Next Picture
MouseWheel Up                 Previous Picture


Revision History:
0.0.6	2006-03-05
 - added filelist menu. 
 - modified to use FreeImage as a DLL instead of as a static library.
 - removed UPX compression caused problem on XP SP2.
 - added autohide option.

0.0.5	2005-12-15
 - fixed GDI resource leak on Win9x.
 - fixed the Sticky function.

0.0.4	2005-10-23
 - fixed a bug that caused the plugin to disappear after changing screen resolution.

0.0.3	2005-10-12
 - updated to FreeImage version 3.8.0
 - fixed "Plugin Toggle" option.

0.0.2	2005-09-24
 - fixed pluginInfo about Bro@ms for xoblite.

0.0.1.1	2005-07-20
 - adds a visible checkmark for "SlideShow" when slideshow is active.

0.0.1	2005-07-18
 - first release


FreeImage version 3.8.0 (Released Sep 5th, 2005)

Supported formats:
bmp	Windows or OS/2 Bitmap
ico	Windows Icon
jpg,jif,jpeg,jpe	JPEG - JFIF Compliant
jng	JPEG Network Graphics
koa	C64 Koala Graphics
iff,lbm	IFF Interleaved Bitmap
mng	Multiple Network Graphics
pbm	Portable Bitmap (ASCII)
pbm	Portable Bitmap (RAW)
pcd	Kodak PhotoCD
pcx	Zsoft Paintbrush
pgm	Portable Greymap (ASCII)
pgm	Portable Greymap (RAW)
png	Portable Network Graphics
ppm	Portable Pixelmap (ASCII)
ppm	Portable Pixelmap (RAW)
ras	Sun Raster Image
tga,targa	Truevision Targa
tif,tiff	Tagged Image File Format
wap,wbmp,wbm	Wireless Bitmap
psd	Adobe Photoshop
cut	Dr. Halo
xbm	X11 Bitmap Format
xpm	X11 Pixmap Format
dds	DirectX Surface
gif	Graphics Interchange Format
hdr	High Dynamic Range Image
