// ----- BBKeyhook v0.5b ----- \\

Author  : Kaloth
Website : http://www.geocities.com/madant8
email   : mulletwarriorextreem@hotmail.com

Licence : GNU General Public License (GPL version 2 or later)

// ----- What is it? ----- \\

I made this plugin to fix my multi-media keyboard under BB4win.
Basically it's a low level keyhook that can map any VK (Virtual Key)
code to a command line action or to the default mixer 'mute', 'volume up'
and 'volume down' actions.

NOTE: This is a beta release, it works on my comp but is far from
being certified stable, use at you own risk!


// ----- How do I train it to my keyboard? ----- \\

All keyboard keys are represented by a VK code. Some manufacturers use different VK codes for special keys, like 'mute' than others. In order to cater for this BBKeyhook as a config mode that you can put it in to by changing the rc setting to 'True'. Once in this state it reports the VK code and Hardware Scan Code of any key you press by displaying it in the BB4win toolbar (make sure the toolbar is visible).

// ----- Bro@ms ----- \\

None as yet, maybe in the future :)

// ----- RC Settings ----- \\

An example rc file is included and should be fairly self explanitory.

But just in case here is a list of the settings and what they do...

-- General Settings --

BBkeyhook.plugin.ConfigMode?:

    If set to true then the VK code and Scan code for any keys pressed is reported to the BB Toolbar. 

BBkeyhook.plugin.volumeStep:

    The amount to change the volume by when a volume action is called. The amount is specified as a percentage.


-- Key Actions --

BBkeyhook.plugin.key<n>:

    Assigns a VK code number to action n.
    (REQUIRED)

BBkeyhook.plugin.scanCode<n>:

    Assigns a Scan code number to action n.
    (OPTIONAL)

BBkeyhook.plugin.command<n>:

    Assigns a command eg: explorer.exe
                 a broam: @BBmuse SetCaptionNow Hello Out There!
       or a mixer action: #MIXER.MUTE#
              (see below for more mixer actions)
    (OPTIONAL)

BBkeyhook.plugin.argument<n>:

    Assigns command line arguments eg: d:/my files/
    (OPTIONAL)

Note: <n> is a number from 0 to 24

-- Mixer Actions --

These are assigned using the 'command' attribute of a key action assignment (see above).
The following 3 actions are available...

#MIXER.MUTE#
#MIXER.VOLUME.UP#
#MIXER.VOLUME.DOWN#


// ----- Change History ----- \\

-- v0.5b

    Fixed application launch focus problem.

-- v0.4b

    Moved broams into the standard 'command' element.

    Added volume step customisation.

-- v0.3b

    Added Scan Code support.

    Added broam actions.

    Integrated mute and volume actions into the standard action assignment system.

-- v0.2b

    A few minor changes (this version was not made public).

-- v0.1b

    Initial Code Version.