
#define IDD_ABOUTBOX                    103
#define IDC_FIVERSION                   1001
#define IDC_FORMATS                     1004
#define IDC_STATIC                      -1
