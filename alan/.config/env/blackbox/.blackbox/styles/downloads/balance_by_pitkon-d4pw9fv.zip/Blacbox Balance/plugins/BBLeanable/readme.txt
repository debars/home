,===========================================================================.
| BBLeanable                                                                |
|  An impersenation plugin for xoblite and BB4Win                           |
|  Written by Brian "Tres`ni" Hartvigsen                                    |
|                                                                    v 0.01 |
`---------------------------------------------------------------------------'

1. Introduction

    I wrote this on a whim.  Part of me wanted to get BBStyleMaker working
  under xoblite, also this looked like a great way to accomplish something I
  was wanting to do for another project.  Using some decompiling on
  BBStyleMaker and BBNote along with some data logging I was able to whip up
  this little tool in a couple hours.
    This plugin is likely more intensive then the BBLean way of doing things
  because xoblite does not store the window (winskin/leanskin) attributes in
  memory.  So on load and reconfigure messages the plugin has to read all
  those settings in, it's a bit of reading.
  
2. Change Log

  v 0.01
   ! Initial Release
   
3. Future Plans

  + Make sure we are mimicking every aspect of BBLean <-> BBNote/StyleMaker
    communication. 