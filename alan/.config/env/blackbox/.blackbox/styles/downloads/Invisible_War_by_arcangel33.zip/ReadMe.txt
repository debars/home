style.name:     Invisible War
style.author:   Arc Angel
style.date:     Jan 03 2004
style.credits:  Inspired by the Deus Ex: Invisible War Website

crap.you.dont.care.about:

I've had a love/hate relationship with LiteStep for a couple of years now, but
never bothered with skinning. Now that Blackbox has matured into a reliable shell
alternative, it's my lean, mean, low-resource-sucking shell of choice.

My hat's off to ironhead and the rest of the BB4Win Dev Team for porting this!

actual.theme.information:

After a painful wait at the Deus Ex:IW website (everybody hates us dial-up users
these days), I was treated to a great flash intro that appealed to my inner nerd.
Ya, ya, the big eyeball thing is overdone and all but I just couldn't help myself.
The wallpaper was ripped from the SWF (Media Player Classic rox) and further
'geekified' with grischka's bsetroot mod command.

You will need Grischka's BSetRoot (v2.0b+) for the wallpaper to work properly,
available on his home page (http://grischka.port5.com) and the nightlies page
(http://bb4win.sourceforge.net/latest/latest/), or you can modify the rootCommand
if you're too lazy.

*nix users will have to change the rootcommand to suit their environment.


