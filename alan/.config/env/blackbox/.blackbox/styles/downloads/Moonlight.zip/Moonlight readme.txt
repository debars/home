Moonlight, the style, was based on the wallpaper "Moonlight Shadow" by BlackHawksRevenge (http://blackhawksrevenge.deviantart.com/) with the artist's permission. This is an excerpt of the permission:

You can use the wallpaper
~BlackHawksRevenge

Thanx, BlackHawksRevenge!