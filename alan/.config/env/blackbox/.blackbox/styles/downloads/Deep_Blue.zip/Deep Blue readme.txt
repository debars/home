Deep Blue, the style, was based on the wallpaper "Blue Moments" by stotty (http://stotty.deviantart.com) with the artist's permission. This is an excerpt of the permission:

...permission is definitely granted for the two deviations you mention on condition they are not modified and credit be given to me...
~stotty

Thanx, stotty!