Techno Dream, the style, was based on the wallpaper "BSD 013 Techno Dream" by vortex (http://vorted.deviantart.com) with the artist's permission. This is an excerpt of the permission:                			

it's ok.. can use it..
~vortex

Thanx, my friend!