Yamaha, the style, was based on the wallpaper "Yamaha FZ1000 Concept" by dangeruss (Russ Schwenkler) based on a design by Maurizio Mancin (http://www.m2m-design.com) with the artist's permission. This is the permission by dangeruss:

"pitkon has blanket permission to port or include and distribute any of my published graphics as part of his styles for Blackbox and other applications / modules of his choosing. - Dangeruss (Russ Schwenkler) russ@dangeruss.net"

Thanx, dangeruss!

This is the permission by Maurizio Mancin:

"OK! Thanx for all!"

Thank YOU, Maurizio!