Fight,the style, was based on the wallpaper "In My Dreams" by aceman67 (http://aceman67.deviantart.com), with the artist's permission. This is an excerpt of the permission:

Sure, I do kinda need the exposure ^_^;
~aceman67

Thanx, aceman67!