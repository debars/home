Moonlight for Blackbox, the style, was based on gef's  Moonlight theme for DesktopX http://www.wincustomize.com/Skins.aspx?LibID=31&view=1&sortby=1&sortdir=DESC&p=1&advanced=0&searchtxt=gef with his permission. This is an excerpt of the permission:

Sure Pete, permission granted - no problem.
~Gef

Thanx, Gef!

A few icons are also from the Moonlight for DesktopX theme, but the rest are 3FX by  danillooc http://danillooc.deviantart.com http://danillooc.wincustomize.org with his pernission. This is an excerpt of the permission:

Pete, 
You have my permission to include the 3FX icons
and neOS Wallpaper in your BlackBox theme
and upload over the GUI community sites.
~danilloOc

Thanx, Dan!

BBLean 1.16z is included with the permission of its developer, Zeytok. Thanx, Zeytok!
