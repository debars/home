Lover, the style, was  based on the wallpaper "Waiting For Lover" by Jannine (http://jannine.deviantart.com/) with the artist's permission. This is an excerpt of the permission:

be my guest :)
~Jannine

Thanx, Jannine!