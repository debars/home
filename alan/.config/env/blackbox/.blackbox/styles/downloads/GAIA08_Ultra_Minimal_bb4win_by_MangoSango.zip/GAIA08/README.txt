Hello,

Thank you for downloading the GAIA08 bb4win styles. You will need the latest version of Blackbox for Windows (bblean 1.16) to use these styles (http://bb4win.sourceforge.net/bblean/). Please install the font first, and copy the buttons.bmp to your "\plugins\bbleanskin" directory.

Remember to save energy by turning your computer off when you don't need it!

Go to gaia.customize.org to get the rest of the suite. 

Sincerely,
Sang (mangosango)

(c)2008 Sang Lee. Please do not redistribute unless you have written permission from me! Mods and ports of this skin are allowed, but as always, give credit where it is due.